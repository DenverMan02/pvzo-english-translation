from repair_tools import edit
edit('PvZ-Server-PoC/gm.py','''        level = int(args[1])
        only_cid = int(args[2]) if len(args) > 2 else None
        srv.load_card_level_curve()
        total = next((t for lv, t, _n in srv._CARD_LEVEL_CURVE if lv == level), 0)
        acct = int(player.get("level", 1))
        done = []
        for cuid, cid, _lv, _exp in store.get_cards(uin):
            if only_cid and cid != only_cid:
                continue
            new_lv, kept = srv.card_level_from_exp(total, cid, acct)
            store.set_card_level(uin, cuid, new_lv, kept)
            done.append((cid, new_lv))''','''        try:
            if not 2 <= len(args) <= 3:
                raise ValueError("植物等级参数不正确。")
            level = int(args[1])
            only_cid = int(args[2]) if len(args) > 2 else None
            srv.load_card_level_curve()
            curve = {lv: total for lv, total, _n in srv._CARD_LEVEL_CURVE}
            if level not in curve:
                raise ValueError("植物等级不在当前等级表中，未修改存档。")
            total = curve[level]
        except ValueError as exc:
            print(str(exc), file=sys.stderr)
            raise SystemExit(1)
        done = []
        with store.atomic_player(player):
            acct = int(player.get("level", 1))
            for cuid, cid, _lv, _exp in store.get_cards(uin):
                if only_cid is not None and cid != only_cid:
                    continue
                new_lv, kept = srv.card_level_from_exp(total, cid, acct)
                store.set_card_level(uin, cuid, new_lv, kept)
                done.append((cid, new_lv))''')
