from pathlib import Path
import json,shutil,subprocess,os
from repair_tools import GAME,WORK
java=Path(r'C:\Users\komi\Documents\Codex\2026-09-29\new-chat-3\_work\jre\jdk-21.0.12.1+1-jre\bin\java.exe')
jar=Path(r'C:\Users\komi\Documents\Codex\2026-09-29\new-chat-3\ffdec_26.3.0\ffdec.jar')
inputs=WORK/'resource-export/inputs';inputs.mkdir(parents=True,exist_ok=True)
out=WORK/'resource-export/rendered'
review=json.loads((WORK/'review_resources.json').read_text(encoding='utf8'))
for asset in review['bug21']['assets']:
    if asset['status'].startswith('same_plant'):
        source=GAME/'webroot/swf/icons/card'/Path(asset['source']).name
        shutil.copy2(source,inputs/source.name)
env=os.environ.copy();env['APPDATA']=str(WORK/'ffdec-appdata')
cmd=[str(java),'-Djava.awt.headless=true','-jar',str(jar),'-ignorebackground','-onerror','abort','-exportTimeout','120','-export','frame,sprite',str(out),str(inputs)]
p=subprocess.run(cmd,env=env,capture_output=True,timeout=180)
(WORK/'resource-export/export.log').write_bytes(p.stdout+p.stderr)
print(p.stdout.decode('utf8','replace')[-2600:]);print('exit',p.returncode)
print('images',len(list(out.rglob('*.png'))))
if p.returncode:raise SystemExit(p.returncode)
