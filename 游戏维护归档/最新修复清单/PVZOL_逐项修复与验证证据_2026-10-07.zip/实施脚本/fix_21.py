"""Restore visible, correctly sized resources with explicit artwork provenance."""
from pathlib import Path
import json,hashlib,math
from PIL import Image,ImageDraw,ImageFont,PngImagePlugin
from repair_tools import GAME,REPAIR,WORK
root=GAME/'webroot'
assets=json.loads((WORK/'review_resources.json').read_text(encoding='utf8'))['bug21']['assets']
font_path=r'C:\Windows\Fonts\msyh.ttc'
manifest=[]

def font(size):return ImageFont.truetype(font_path,size)
def save(asset,image,meaning,method,source='',evidence=''):
    path=root/asset.lstrip('/');path.parent.mkdir(parents=True,exist_ok=True)
    meta=PngImagePlugin.PngInfo();meta.add_text('Meaning',meaning);meta.add_text('Provenance',method+': '+source)
    image.save(path,pnginfo=meta,optimize=True)
    manifest.append(dict(path=asset,size=list(image.size),meaning=meaning,method=method,source=source,
                         dimension_evidence=evidence,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))

def panel(size,colour='#35493a',border='#c7a86c',clear=False,margin=3):
    w,h=size;im=Image.new('RGBA',size);d=ImageDraw.Draw(im)
    d.rounded_rectangle((0,0,w-1,h-1),radius=min(7,w//8,h//4),fill=(17,25,19,180))
    d.rounded_rectangle((1,1,w-2,h-2),radius=min(6,w//8,h//4),fill=colour,outline=border,width=2)
    if clear:d.rectangle((margin,margin,w-margin-1,h-margin-1),fill=(0,0,0,0))
    elif w>80 and h>50:
        d.line((7,7,w-8,7),fill='#76906c');d.line((7,h-8,w-8,h-8),fill='#202f25')
    return im

def symbol(kind,colour='#f8e398',size=(25,25),label=''):
    w,h=size;s=4;im=Image.new('RGBA',(w*s,h*s));d=ImageDraw.Draw(im)
    def xy(points):return [(int(x*w*s/100),int(y*h*s/100)) for x,y in points]
    def poly(points,fill=colour):d.polygon(xy(points),fill=fill)
    def line(points,fill=colour,width=7):d.line(xy(points),fill=fill,width=max(1,int(width*w*s/100)))
    def ellipse(box,fill=colour):
        x1,y1,x2,y2=box;d.ellipse((x1*w*s/100,y1*h*s/100,x2*w*s/100,y2*h*s/100),fill=fill)
    shadow='#182c24'
    if kind=='sword':
        poly([(27,73),(71,14),(87,13),(85,30),(40,81)]);line([(20,55),(55,88)],'#b48645',9);line([(26,72),(11,92)],'#d49b4d',12)
    elif kind=='shield':
        poly([(17,14),(83,14),(82,59),(68,78),(50,91),(32,78),(18,59)]);poly([(28,25),(72,25),(69,56),(50,75),(31,56)],'#3489b0');line([(50,25),(50,70)],'#d7edf6',6)
    elif kind=='burst':
        points=[]
        for i in range(16):
            a=i*math.pi/8-math.pi/2;r=44 if i%2==0 else 19;points.append((50+math.cos(a)*r,50+math.sin(a)*r))
        poly(points);ellipse((35,35,65,65),'#e17c40')
    elif kind=='flag':
        line([(25,8),(25,92)],'#dbc38c',7);poly([(28,13),(88,13),(76,35),(88,53),(28,53)],'#f2c252');poly([(40,23),(68,23),(62,33),(68,43),(40,43)],'#bd5034')
    elif kind=='boots':
        poly([(27,12),(69,12),(64,58),(88,68),(90,83),(17,83),(19,64),(32,59)],'#70d2ab');line([(5,37),(20,37)],'#f1f5ca',5);line([(4,53),(16,53)],'#f1f5ca',5)
    elif kind=='leaf':
        ellipse((17,13,80,73),'#6cbd64');poly([(21,77),(37,24),(73,17),(43,74)],'#95e277');line([(22,89),(66,26)],'#d4e8ac',5)
    elif kind=='clock':
        ellipse((10,13,89,92));ellipse((20,23,79,82),'#376a69');line([(50,32),(50,55),(70,64)],'#e9eccc',7);line([(38,6),(62,6)],'#ddaa5a',8)
    elif kind=='coin':
        ellipse((11,11,90,90));ellipse((21,21,80,80),'#d7a045');line([(50,29),(50,72)],'#fff2af',9)
    elif kind=='teeth':
        poly([(10,22),(91,22),(81,67),(66,44),(50,76),(33,44),(21,68)],'#f8f1d2');line([(10,19),(91,19)],'#ee817a',8)
    elif kind=='helmet':
        d.pieslice((10*w*s/100,15*h*s/100,90*w*s/100,95*h*s/100),180,360,fill='#bfbc8d');line([(7,59),(92,59)],colour,9);line([(51,19),(51,50)],'#dedcbb',7)
    elif kind=='bolt':poly([(56,6),(20,56),(43,56),(34,96),(85,41),(58,41)],'#a7e4ff')
    elif kind=='deck':
        poly([(8,22),(70,8),(89,77),(26,92)],'#7ea48b');poly([(22,15),(83,15),(83,88),(22,88)],'#507a68')
        if label:
            f=font(int(58*w*s/100));d.text((w*s/2,h*s/2),label[:1],font=f,anchor='mm',fill='#fff0bb',stroke_width=1,stroke_fill=shadow)
    elif kind=='document':
        poly([(19,7),(66,7),(83,25),(83,91),(19,91)],'#d4dac1');line([(32,38),(68,38)],'#365146',7);line([(32,55),(68,55)],'#365146',7);line([(32,72),(60,72)],'#365146',7)
    else:raise ValueError(kind)
    return im.resize(size,Image.Resampling.LANCZOS)

base_symbols={10040:44,10060:53,10070:41,113:41,125:79,470:76,750:61,920:45}
for a in assets:
    if not a['status'].startswith('same_plant'):continue
    ident=int(a['path'].split('/')[-1].split('_')[0]);sprite_id=base_symbols[ident]
    folder=WORK/'resource-export/base-rendered'/f'card_icon_{ident}.swf'
    source=next(p for p in folder.iterdir() if p.name==f'DefineSprite_{sprite_id}' or p.name.startswith(f'DefineSprite_{sprite_id}_'))/'1.png'
    art=Image.open(source).convert('RGBA');art=art.crop(art.getbbox())
    limit=(62,62) if '/smallIcon/' in a['path'] else (90,90)
    art.thumbnail(limit,Image.Resampling.LANCZOS)
    image=Image.new('RGBA',(330,240));image.alpha_composite(art,(2,2))
    save(a['path'],image,f'植物/傀儡图标 {ident} 的完整基础模型','same_plant_base_render',f'swf/icons/card/card_icon_{ident}.swf#sprite{sprite_id}',
         '同目录现存PNG均330x240；完整模型裁边留2px透明，基础外观不冒充原服饰图')

save('/image/talent/ui/starSmall.png',Image.open(WORK/'resource-export/ui/star/216_Card_star.png').convert('RGBA'),
     '天赋星级标记','same_purpose_export','swf/resource.swf#Card_star(216)','同用途位图原尺寸17x16')
save('/image/puzzle/ICON.png',Image.open(root/'image/item/2020.png').convert('RGBA').resize((24,24),Image.Resampling.LANCZOS),
     '拼图点（ItemInfo id2020）','same_currency_rescale','image/item/2020.png','CardPuzzleGroupPanel/Icon 明确24x24')

talents={2304:('leaf','生龙活虎'),2303:('sword','粗枝大叶'),2003:('coin','跳楼降价'),2002:('clock','减速魔法'),
         2001:('helmet','人品爆发'),2602:('leaf','春草又生'),2501:('clock','快速生长'),2502:('burst','冬瓜爆炸'),2403:('teeth','刀锋利齿'),2402:('teeth','锋利尖牙')}
for ident,(kind,meaning) in talents.items():
    im=panel((50,50),border='#8fb569');art=symbol(kind,size=(34,34));im.alpha_composite(art,(8,3))
    d=ImageDraw.Draw(im);d.rounded_rectangle((3,36,46,48),radius=3,fill='#203829');d.text((25,42),meaning[:2],font=font(10),anchor='mm',fill='#eef2cd')
    save(f'/image/talent/talent/{ident}.png',im,meaning,'reconstructed_art',f'plantTalentInfo metadata id{ident}','同目录天赋图标50x50')

feature={1:('sword','攻击'),3:('bolt','技力及技能伤害'),5:('boots','闪避'),11:('shield','技能防御')}
for ident,(kind,meaning) in feature.items():
    save(f'/image/card/feature/{ident}.png',symbol(kind),meaning,'reconstructed_art','ConfigCardBuff icon='+str(ident),'CardFeatureIcon:25x25')

deck={123:'攻',111:'弹',117:'联',118:'幻',109:'交',113:'乐',102:'冰',105:'衡'}
semantics=json.loads((WORK/'resource_supplement_semantics.json').read_text(encoding='utf8'))['deck_badges']
for ident,label in deck.items():
    meaning='组合徽章：'+'／'.join(row['name'] for row in semantics if row['icon']==str(ident))
    assert meaning!='组合徽章：'
    save(f'/image/card/feature/{ident}.png',symbol('deck',label=label),meaning,'reconstructed_art','cardDeckShow icon='+str(ident),'CardDeckIcon:25x25；共享组合徽章，文字主题为重绘设计')

for quality,colour in enumerate(['#c7d5bc','#8acd64','#64b5e8','#bc8be9','#ffd164'],1):
    save(f'/image/card/feature_bg/{quality}.png',panel((27,27),border=colour),f'品质{quality}徽章背景','reconstructed_art','CardDeckIcon background tier','CardDeckIcon:27x27')
for ident,kind,meaning in [(1,'burst','大招技能'),(2,'flag','队长技能')]:
    save(f'/image/card/skill/{ident}.png',symbol(kind),meaning,'reconstructed_art','CardGlobals CARD_SKILL_SKILL/LEADER','CardSkillIcon:25x25')

panels={
 '/image/talent/ui/talentBJ.png':((56,46),'天赋小卡框','PTBar72x80，x8/y10，studyBtn y58'),
 '/swf/fuben/union_fuben_bk.png':((364,44),'联盟副本剩余次数背景','UnionFubenLeftTimesBox:364x44'),
 '/swf/fuben/fuben_name_back.png':((127,25),'副本章节名称背景','FubenCell chapter name:127x25'),
 '/image/card/VIP_TIP_BG.png':((194,69),'卡牌VIP开启提示条','ModuleCard InitializeComponent1249:194x69'),
 '/image/item/ui/itemSlot_bg.png':((50,50),'背包格子背景','同目录物品格/品质背景50x50'),
 '/image/puzzle/LIST_BG.png':((280,601),'拼图列表背景','CardPuzzleList:280x601'),
 '/image/puzzle/CELL_BG.png':((224,68),'拼图奖励条目背景','CardPuzzleTipCell:224x68'),
 '/image/puzzle/CELL_TITLE_BG.png':((149,24),'拼图奖励标题背景','CardPuzzleTipCell:149x24'),
}
for path,(size,meaning,evidence) in panels.items():save(path,panel(size),meaning,'reconstructed_art','client component geometry',evidence)
save('/image/ui/armyInfo.png',symbol('document',size=(12,12)),'军情信息入口图标','reconstructed_art','EmbattleView topBox y37 height50','原始尺寸未知，12x12适配同排13pt军情文字')
save('/image/item/ui/borderWhite.png',panel((50,50),border='#fffbe8',clear=True,margin=3),'物品白色选中边框','reconstructed_art','50px物品格，中心透明','同目录物品格50x50')
save('/swf/fuben/icon_rect.png',panel((60,60),border='#c5ad67',clear=True,margin=7),'关卡图标边框','reconstructed_art','46px关卡图中心透明','客户端两处明确60x60')
frame=panel((423,352),colour='#634728',border='#d6b978')
ImageDraw.Draw(frame).rectangle((9,7,413,344),fill=(0,0,0,0))
save('/image/puzzle/PUZZLE_FRAME.png',frame,'拼图板边框','reconstructed_art','中心405x338完全透明','CardPuzzleView frame423x352；inner405x338')
pointer=Image.new('RGBA',(29,46));d=ImageDraw.Draw(pointer)
d.polygon([(3,3),(25,3),(25,24),(28,24),(14,43),(0,24),(3,24)],fill='#f5ce61',outline='#6a4526',width=2)
d.line((7,8,21,8),fill='#fff2b2',width=2)
save('/swf/fuben/union_fuben_curStage.png',pointer,'联盟当前关卡指针','reconstructed_art','原位透明箭头','UnionFuben:29x46')
assert {a['path'] for a in assets}=={a['path'] for a in manifest},'Missing or extra paths'
result={'note':'No claim of exact original artwork restoration. 8 same-model base renders, 2 same-purpose sources, 42 reconstructed icons/backgrounds. Flash live visual acceptance remains unverified.', 'assets':manifest}
(root/'resource-repair-manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
(REPAIR/'ready/resource-02-files.json').write_text(json.dumps(['webroot'+a['path'] for a in manifest]+['webroot/resource-repair-manifest.json'],ensure_ascii=False,indent=2),encoding='utf8')
print('Prepared resources',len(manifest))
