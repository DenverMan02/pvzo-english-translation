from repair_tools import edit

edit('PvZ-Server-PoC/pvz_poc_server.py', 'def uvarint(n: int) -> bytes:\n    out = bytearray()',
     'def uvarint(n: int) -> bytes:\n    if n < 0:\n        raise ValueError("unsigned varint cannot encode a negative value")\n    out = bytearray()')
edit('PvZ-Server-PoC/gm.py', 'def passto(uin, stage, level, sub):', '''PLAYER_UINT32_FIELDS = frozenset((
    "level", "exp", "coin", "sun", "energy", "ticket", "present_ticket",
    "fame", "friend_point", "buy_energy_num", "foster_ticket", "lucky",
    "contrib_val", "light", "last_pay_time", "prestige", "puppet_skill_val",
    "puppet_energy",
))


def player_level_values():
    levels = {_i(row, "id") for row in _clientdb_dicts("levelInfo.txt")}
    levels.discard(0)
    if not levels:
        raise ValueError("账号等级配置缺失，未修改存档。")
    return levels


def validate_player_fields(fields):
    """Check the unsigned login attributes before any field is persisted."""
    for key, value in fields.items():
        if key not in PLAYER_UINT32_FIELDS:
            continue
        if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 4294967295:
            raise ValueError("%s 必须是 0—4294967295 的整数，未修改存档。" % key)
        if key == "level" and value not in player_level_values():
            raise ValueError("账号等级不在当前等级表中，未修改存档。")
    return fields


def passto(uin, stage, level, sub):''')
edit('PvZ-Server-PoC/gm.py', '        store.save_player(uin, **fields)\n        print("updated uin=%d: %s\\n" % (uin, fields))',
     '''        try:
            validate_player_fields(fields)
        except ValueError as exc:
            print(str(exc), file=sys.stderr)
            raise SystemExit(1)
        store.save_player(uin, **fields)
        print("updated uin=%d: %s\\n" % (uin, fields))''')
edit('launcher.py', '        def apply_main():\n            if not save_profile():', '''        def apply_main():
            from gm import validate_player_fields
            numeric = {}
            for _label, key in FIELDS:
                val = ed_vars[key].get().strip()
                if val.lstrip("-").isdigit():
                    numeric[key] = int(val)
            try:
                validate_player_fields(numeric)
            except ValueError as exc:
                status.configure(text=str(exc), fg=STOP)
                return
            if not save_profile():''')
edit('PvZ-Server-PoC/admin_server.py', '("level", "账号等级", "number", 1, 999),',
     '("level", "账号等级", "number", 1, max(gm.player_level_values())),')
edit('PvZ-Server-PoC/admin_server.py', '        vip = _integer(form, "vip_level", 0, 3, "VIP 等级")', '''        try:
            gm.validate_player_fields(values)
        except ValueError as exc:
            raise ValidationError(str(exc))
        vip = _integer(form, "vip_level", 0, 3, "VIP 等级")''')
