from repair_tools import GAME,edit
import ast
relative='PvZ-Server-PoC/pvz_poc_server.py'
text=(GAME/relative).read_text(encoding='utf-8')
start=text.index('    if chest is None:',text.index('def handle_item_use'))
end=text.index('    name, quality, multi = chest',start)
edit(relative,text[start:end],'''    if chest is None:
        import item_use_repairs
        return item_use_repairs.use(sys.modules[__name__], cmd_data, player)
''')
edit('PvZ-Server-PoC/player_store.py','    "vip_level": 0,','    "vip_card_id": 0,\n    "vip_endtime": 0,\n    "vip_level": 0,')
edit(relative,'def load_vip_tiers():','_VIP_CARDS = {}\n\n\ndef load_vip_tiers():')
edit(relative,'    global _VIP_TIERS\n    if _VIP_TIERS is None:','    global _VIP_TIERS, _VIP_CARDS\n    if _VIP_TIERS is None:')
edit(relative,'''                if col(r, "vipType") != "1":       # paid tiers only (levels 1/2/3)
                    continue''','''                if col(r, "vipType") not in ("1", "2"):
                    continue''')
edit(relative,'                _VIP_TIERS[lvl] = {','                template = {')
edit(relative,'                    "level": lvl,\n                    "cardId":','                    "level": lvl, "type": int(col(r, "vipType")), "day": int(col(r, "day") or 0),\n                    "cardId":')
edit(relative,'''        log.info("loaded %d VIP tiers", len(_VIP_TIERS))''','''                _VIP_CARDS[template["cardId"]] = template
                if template["type"] == 1:
                    _VIP_TIERS[lvl] = template
        log.info("loaded %d VIP tiers", len(_VIP_TIERS))''')
edit(relative,'''    lvl = int(player.get("vip_level") or 0)
    return load_vip_tiers().get(lvl) if lvl else None''','''    tiers = load_vip_tiers()
    card_id = int(player.get("vip_card_id") or 0)
    if card_id:
        if int(player.get("vip_endtime") or 0) <= int(time.time()):
            return None
        return _VIP_CARDS.get(card_id)
    lvl = int(player.get("vip_level") or 0)
    return tiers.get(lvl) if lvl else None


def active_vip_level(player):
    tier = vip_tier(player)
    return tier["level"] if tier else 0''')
# Every permission path must honor the same expiry, including garden/equipment gates.
text=(GAME/relative).read_text(encoding='utf-8')
for node in ast.parse(text).body:
    if not isinstance(node,ast.FunctionDef) or node.name=='vip_tier':continue
    old=''.join(text.splitlines(True)[node.lineno-1:node.end_lineno])
    new=old.replace('int(player.get("vip_level") or 0)','active_vip_level(player)')
    if old!=new:edit(relative,old,new)
edit(relative,'+ pb_varint_field(3, _VIP_PRIV_ENDTIME))','+ pb_varint_field(3, int(player.get("vip_endtime") or _VIP_PRIV_ENDTIME) if pid != _GARDEN_AUTO_FERTILIZER_PRIV else _VIP_PRIV_ENDTIME))')
edit(relative,'+ pb_varint_field(2, _VIP_PRIV_ENDTIME)                    # endTime','+ pb_varint_field(2, int(player.get("vip_endtime") or _VIP_PRIV_ENDTIME)) # endTime')
edit(relative,'+ pb_varint_field(6, 1)                                   # type = paid','+ pb_varint_field(6, t["type"])                          # paid or gifted')
edit('PvZ-Server-PoC/gm.py','''            if "td_privilege" in updates:
                import time''','''            if "vip_level" in updates:
                updates.update(vip_card_id=0, vip_endtime=0)
            if "td_privilege" in updates:
                import time''')
edit('PvZ-Server-PoC/gm.py','store.save_player(uin, vip_level=tier)','store.save_player(uin, vip_level=tier, vip_card_id=0, vip_endtime=0)')
edit('PvZ-Server-PoC/admin_server.py','        values.update(vip_level=vip, td_privilege=privilege,','        values.update(vip_level=vip, vip_card_id=0, vip_endtime=0, td_privilege=privilege,')
