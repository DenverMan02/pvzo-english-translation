from pathlib import Path
import json,struct,zlib,subprocess,os
from export_resource_art import java,jar
from repair_tools import WORK,GAME
index=json.loads((WORK/'swf_symbol_index.json').read_text(encoding='utf8'))
inputs=WORK/'resource-export/base-inputs';inputs.mkdir(parents=True,exist_ok=True)
for ident in (10040,10060,10070,113,125,470,750,920):
    relative=f'swf/icons/card/card_icon_{ident}.swf'
    symbols=next(e['symbols'] for e in index if e['path']==relative)
    holders={s['id'] for s in symbols if s['name'].startswith('holder_custom')}
    raw=(GAME/'webroot'/relative).read_bytes()
    data=zlib.decompress(raw[8:]) if raw[:3]==b'CWS' else raw[8:]
    p=(5+4*(data[0]>>3)+7)//8+4;head=data[:p];tags=[]
    while p<len(data):
        h=struct.unpack_from('<H',data,p)[0];p+=2;kind,size=h>>6,h&63
        if size==63:size=struct.unpack_from('<I',data,p)[0];p+=4
        payload=data[p:p+size];p+=size
        if kind==39 and struct.unpack_from('<H',payload)[0] in holders:
            payload=payload[:2]+struct.pack('<HHH',1,1<<6,0)
        tags.append(struct.pack('<HI',kind<<6|63,len(payload))+payload)
        if not kind:break
    body=head+b''.join(tags)
    (inputs/Path(relative).name).write_bytes(b'CWS'+raw[3:4]+struct.pack('<I',len(body)+8)+zlib.compress(body))
env=os.environ.copy();env['APPDATA']=str(WORK/'ffdec-appdata')
p=subprocess.run([str(java),'-Djava.awt.headless=true','-jar',str(jar),'-ignorebackground','-onerror','abort','-export','sprite',str(WORK/'resource-export/base-rendered'),str(inputs)],env=env,capture_output=True,timeout=120)
(WORK/'resource-export/base-export.log').write_bytes(p.stdout+p.stderr)
print('base-render exit',p.returncode)
raise SystemExit(p.returncode)
