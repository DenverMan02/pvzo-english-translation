from repair_tools import edit,GAME
import ast
relative='PvZ-Server-PoC/pvz_poc_server.py'
edit(relative,'def build_player_units(player, placements=None, owner_roles=None):','def build_player_units(player, placements=None, owner_roles=None, leader_team_id=1):')
edit(relative,'saved_leader = store.get_formation_leader(player["uin"], 1)','saved_leader = store.get_formation_leader(player["uin"], leader_team_id)')
for name,argument in [('_arena_challenge','3 if rank else 2'),('handle_rankarena_challenge','3')]:
    text=(GAME/relative).read_text(encoding='utf-8')
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name)
    old=''.join(text.splitlines(True)[node.lineno-1:node.end_lineno])
    assert old.count('left = build_player_units(player)')==1
    edit(relative,old,old.replace('left = build_player_units(player)','left = build_player_units(player, leader_team_id='+argument+')'))
