from repair_tools import GAME,edit
import ast
relative='PvZ-Server-PoC/pvz_poc_server.py'
edit(relative,'report_uid=0):','report_uid=0, recorded_at=None):')
edit(relative,'    now = int(time.time())\n    uid = int(report_uid or now)','    now = int(recorded_at if recorded_at is not None else time.time())\n    uid = int(report_uid)')
for name,field in [('_arena_challenge','field'),('handle_rankarena_challenge','"rank_arena_data"')]:
    text=(GAME/relative).read_text(encoding='utf-8')
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name)
    old=''.join(text.splitlines(True)[node.lineno-1:node.end_lineno])
    save='    _save_json_state(player, '+field+', data)\n'
    assert old.count(save)==1
    new=old.replace(save,'')
    new=new.replace('    report_id = _store_battle_report(report)','    report_id = _store_battle_report(report)\n    data["records"][-1].update(report_uid=report_id, ts=int(time.time()))\n'+save.rstrip('\n'))
    edit(relative,old,new)
edit(relative,'bool(rec.get("win", True)), int(rec.get("change", 10)))','bool(rec.get("win", True)), int(rec.get("change", 10)), report_uid=int(rec.get("report_uid") or 0), recorded_at=rec.get("ts", 0))')
edit(relative,'bool(rec.get("win", True)), int(rec.get("change", 10)), rank=True)','bool(rec.get("win", True)), int(rec.get("change", 10)), rank=True, report_uid=int(rec.get("report_uid") or 0), recorded_at=rec.get("ts", 0))')
