from repair_tools import edit,GAME
edit('PvZ-Server-PoC/player_store.py','''        # Card fruit progression: quality is the fruit slot''','''        con.execute("CREATE TABLE IF NOT EXISTS td_card_grants "
                    "(uin INTEGER NOT NULL, plant_id INTEGER NOT NULL, PRIMARY KEY(uin,plant_id))")
        # Card fruit progression: quality is the fruit slot''')
text=(GAME/'PvZ-Server-PoC/pvz_poc_server.py').read_text(encoding='utf-8')
start=text.index('    uin = player["uin"]',text.index('def ensure_player_cards'))
end=text.index('\n\n\ndef _card_gene_active_stage',start)
old=text[start:end]
wipe=old[old.index('    # migrate:'):old.index('    have = {cid')]
new=old.replace(wipe,'    # Existing card progress is preserved; never wipe the collection for grant migration.\n')
new=new.replace('    for pid in player.get("plants", []):\n        if int(pid) in have_td:\n            continue\n        cid, _st = td_plant_to_card(pid)', '''    for pid in store.get_player_plants(uin):
        cid, _st = td_plant_to_card(pid)
        if not cid:
            continue
        with store._db() as con:
            first = con.execute("INSERT OR IGNORE INTO td_card_grants(uin,plant_id) VALUES (?,?)", (uin,int(pid))).rowcount
        if not first or int(pid) in have_td:
            continue''')
new='    with store.atomic_player(player):\n'+''.join('    '+line if line.strip() else line for line in new.splitlines(True))
edit('PvZ-Server-PoC/pvz_poc_server.py',old,new)
text=(GAME/'PvZ-Server-PoC/pvz_poc_server.py').read_text(encoding='utf-8')
start=text.index('    fields = parse_varint_fields',text.index('def handle_card_recycle('))
end=text.index('\n\n\ndef handle_card_autorecycle',start)
old=text[start:end]
new='    with store.atomic_player(player):\n        ensure_player_cards(player)\n'+''.join('    '+line if line.strip() else line for line in old.splitlines(True))
edit('PvZ-Server-PoC/pvz_poc_server.py',old,new)
