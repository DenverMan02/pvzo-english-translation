"""Deploy exactly one reviewed, tested repair; keep a before-copy for every file."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import socket
import sys
from datetime import datetime

ROOT=Path(r'D:\pvzol本地最新最新ol').resolve()
REPAIR=Path(__file__).resolve().parent/'repair'
issue=sys.argv[1]
ledger_path=REPAIR/'ledger.json'
ledger=json.loads(ledger_path.read_text(encoding='utf-8'))
current=next(s for s in ledger['steps'] if s['status']!='deployed')
assert current['id']==issue,(current['id'],issue)
change=json.loads((REPAIR/'ready'/f'{issue}.json').read_text(encoding='utf-8'))
assert change['issue']==issue
with socket.socket() as sock:
    sock.settimeout(.4)
    assert sock.connect_ex(('127.0.0.1',9001)) != 0,'游戏服务正在运行；请先停止以便安全替换。'
targets=[]
for entry in change['files']:
    target=(ROOT/entry['relative']).resolve()
    target.relative_to(ROOT)
    assert target.name not in ('players.db','guild_local.db')
    assert entry['relative'].startswith('pvzol本地/')
    prepared=Path(entry['prepared_file']).resolve()
    prepared.relative_to((REPAIR/'game').resolve())
    old_hash=hashlib.sha256(target.read_bytes()).hexdigest() if target.exists() else None
    assert old_hash==entry['old_sha256'],f'原文件已改变：{target}'
    payload=prepared.read_bytes()
    assert hashlib.sha256(payload).hexdigest()==entry['new_sha256']
    targets.append((entry,target,payload))
backup=(ROOT/'修复备份'/ledger['backup_directory']/f"{current['sequence']:02d}-{issue}").resolve()
backup.relative_to(ROOT/'修复备份')
backup.mkdir(parents=True,exist_ok=False)
changed=[]
try:
    for entry,target,payload in targets:
        if target.exists():
            saved=backup/entry['relative']
            saved.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(target,saved)
        target.parent.mkdir(parents=True,exist_ok=True)
        temporary=target.with_name(target.name+'.repair-tmp')
        temporary.write_bytes(payload)
        os.replace(temporary,target)
        changed.append((entry,target))
        assert hashlib.sha256(target.read_bytes()).hexdigest()==entry['new_sha256']
except Exception:
    for entry,target in reversed(changed):
        saved=backup/entry['relative']
        if saved.exists():
            shutil.copy2(saved,target)
        else:
            target.unlink()
    raise
(backup/'change.json').write_text(json.dumps(change,ensure_ascii=False,indent=2),encoding='utf-8')
current.update(status='deployed',tests=change['tests'],files=[x['relative'] for x in change['files']],backup=str(backup))
ledger_path.write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'deployed':issue,'sequence':current['sequence'],'backup':str(backup),'files':current['files']},ensure_ascii=False))
