from repair_tools import edit
edit('PvZ-Server-PoC/gm.py','def validate_uin(raw):','''EDITOR_FIELDS = frozenset(("level", "coin", "sun", "ticket", "present_ticket",
                           "fame", "energy", "friend_point", "vip_level", "td_privilege"))


def apply_editor_patch(uin, request):
    fields = request.get("fields", {})
    expected = request.get("expected", {})
    if not isinstance(fields, dict) or not isinstance(expected, dict) or set(fields) - EDITOR_FIELDS:
        raise ValueError("编辑字段不正确。")
    validate_player_fields(fields)
    for key, maximum in (("vip_level", 3), ("td_privilege", 1)):
        if key in fields and (type(fields[key]) is not int or not 0 <= fields[key] <= maximum):
            raise ValueError("%s 设置不正确。" % key)
    player, _ = store.get_or_create_player(uin)
    with store.atomic_player(player) as con:
        for key in fields:
            if key not in expected or player.get(key) != expected[key]:
                raise ValueError("%s 已被其他操作修改，请重新核对后保存。" % key)
        updates = dict(fields)
        if "td_privilege" in updates:
            import time
            updates["td_privilege_endtime"] = int(time.time()) + 86400 * 365 if updates["td_privilege"] else 0
        if updates:
            store.save_player(uin, **updates)
        return dict(con.execute("SELECT * FROM players WHERE uin=?", (uin,)).fetchone())


def validate_uin(raw):''')
edit('PvZ-Server-PoC/gm.py','''    args = sys.argv[2:]
    if args and args[0] == "profile":''','''    args = sys.argv[2:]
    if args and args[0] == "editor":
        try:
            if len(args) != 2:
                raise ValueError("编辑请求参数不正确。")
            result = apply_editor_patch(uin, json.loads(args[1]))
        except (ValueError, TypeError) as exc:
            print(str(exc), file=sys.stderr)
            raise SystemExit(1)
        print(json.dumps(result, ensure_ascii=False))
        return
    if args and args[0] == "profile":''')
edit('launcher.py','def python_command(script, *args):','''def refresh_editor_fields(variables, baseline, latest):
    for key, variable in variables.items():
        if variable.get().strip() == str(baseline[key]):
            variable.set(str(latest[key]))
            baseline[key] = latest[key]


def python_command(script, *args):''')
edit('launcher.py','''            return ok

        # --- 个人资料''','''            if ok:
                with store._db() as con:
                    latest = dict(con.execute("SELECT * FROM players WHERE uin=?", (int(uin),)).fetchone())
                refresh_editor_fields(ed_vars, baseline, latest)
                player.update(latest)
            return ok

        # --- 个人资料''')
edit('launcher.py','''        ed_vars = {}
        for i, (label, key)''','''        ed_vars = {}
        baseline = {key: player.get(key, 0) for _label, key in FIELDS}
        baseline.update(vip_level=player.get("vip_level", 0), td_privilege=player.get("td_privilege", 0))
        for i, (label, key)''')
edit('launcher.py','''            args = [uin]
            for _label, key in FIELDS:
                val = ed_vars[key].get().strip()
                if val.lstrip("-").isdigit():
                    args += [key, val]
            ok = True
            if len(args) > 1:
                ok = self._run_gm(args)[0]
            ok = self._run_gm([uin, "vip", str(VIP_OPTS.index(vip_var.get()))])[0] and ok
            ok = self._run_gm([uin, "tdpriv", str(TD_OPTS.index(td_var.get()))])[0] and ok
            status.configure(text=("已保存，下次开始游戏时同步资料和设置。" if ok else "存档保存失败 — 请查看服务器日志"),
                             fg=(ACCENT if ok else STOP))''','''            values = dict(numeric)
            values.update(vip_level=VIP_OPTS.index(vip_var.get()), td_privilege=TD_OPTS.index(td_var.get()))
            fields = {key: value for key, value in values.items() if value != baseline[key]}
            request = {"fields": fields, "expected": {key: baseline[key] for key in fields}}
            ok, out = self._run_gm([uin, "editor", json.dumps(request, ensure_ascii=False)])
            if not ok:
                status.configure(text="存档保存失败：" + out.strip(), fg=STOP)
                return
            latest = json.loads(out)
            for key in fields:
                baseline[key] = latest[key]
                if key in ed_vars:
                    ed_vars[key].set(str(latest[key]))
            refresh_editor_fields(ed_vars, baseline, latest)
            player.update(latest)
            status.configure(text="已保存，下次开始游戏时同步资料和设置。", fg=ACCENT)''')
