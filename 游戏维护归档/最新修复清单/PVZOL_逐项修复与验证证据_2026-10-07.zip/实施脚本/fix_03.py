from repair_tools import edit
edit('launcher.py',"The account must fit the server's SQLite signed integer key.","The account must fit the game's unsigned 32-bit transport field.")
edit('launcher.py','and 0 < int(value) <= 9223372036854775807)','and 0 < int(value) <= 4294967295)')
edit('launcher.py','请输入有效的纯数字账号（1 到 9223372036854775807）。','请输入有效的纯数字账号（1 到 4294967295）。')
edit('launcher.py','请先输入一个数字账号。','请输入有效的纯数字账号（1 到 4294967295）。')
edit('PvZ-Server-PoC/gm.py','import sys\nimport player_store','import sys\nimport re\nimport player_store')
edit('PvZ-Server-PoC/gm.py','def main():','''def validate_uin(raw):
    text = str(raw)
    if re.fullmatch(r"[0-9]{1,19}", text) is None or not 1 <= int(text) <= 4294967295:
        raise ValueError("账号必须是 1—4294967295 的纯数字。")
    return int(text)


def main():''')
edit('PvZ-Server-PoC/gm.py','''    store.init_db()
    uin = int(sys.argv[1])''','''    try:
        uin = validate_uin(sys.argv[1])
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
    store.init_db()''')
edit('PvZ-Server-PoC/admin_server.py','''    title = label or key
    try:
        value = int(raw)''','''    title = label or key
    if key == "uin":
        try:
            return gm.validate_uin(raw)
        except ValueError as exc:
            raise ValidationError(str(exc))
    try:
        value = int(raw)''')
edit('PvZ-Server-PoC/pvz_poc_server.py','''                    uin = info.get("uin") or 0
                    player, is_new = store.get_or_create_player(uin)''','''                    uin = info.get("uin") or 0
                    if not 1 <= uin <= 4294967295:
                        log.warning("reject invalid login account %s", uin)
                        return
                    player, is_new = store.get_or_create_player(uin)''')
edit('PvZ-Server-PoC/tests/test_launcher_lifecycle.py',"('001','700000200','9223372036854775807')","('001','700000200','4294967295')")
