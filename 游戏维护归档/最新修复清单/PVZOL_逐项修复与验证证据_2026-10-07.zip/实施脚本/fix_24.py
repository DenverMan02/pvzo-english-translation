from repair_tools import edit
edit('launcher.py','def python_command(script, *args):','''PRIVILEGE_DEPENDENCIES = {"vip_level": ("vip_card_id", "vip_endtime"),
                          "td_privilege": ("td_privilege_endtime",)}


def editor_privilege_levels(player, now=None):
    now = int(time.time()) if now is None else now
    vip = int(player.get("vip_level") or 0)
    if int(player.get("vip_card_id") or 0) and int(player.get("vip_endtime") or 0) <= now:
        vip = 0
    td = int(player.get("td_privilege") or 0)
    end = int(player.get("td_privilege_endtime") or 0)
    return {"vip_level": vip, "td_privilege": td if end == 0 or end > now else 0}


def editor_privilege_fields(values, shown_baseline, dirty):
    return {key: value for key, value in values.items()
            if value != shown_baseline[key] or key in dirty}


def refresh_editor_privileges(variables, options, baseline, shown_baseline, dirty, latest, committed=()):
    levels = editor_privilege_levels(latest)
    for key, variable in variables.items():
        if key in committed or (key not in dirty and options[key].index(variable.get()) == shown_baseline[key]):
            baseline[key] = latest.get(key, 0)
            for dependency in PRIVILEGE_DEPENDENCIES[key]:
                baseline[dependency] = latest.get(dependency, 0)
            shown_baseline[key] = levels[key]
            variable.set(options[key][levels[key]])
            dirty.discard(key)


def python_command(script, *args):''')
edit('launcher.py','''                for key, variable, options in (("vip_level", vip_var, VIP_OPTS), ("td_privilege", td_var, TD_OPTS)):
                    if options.index(variable.get()) == baseline[key]:
                        variable.set(options[int(latest[key])])
                        baseline[key] = latest[key]''','''                refresh_editor_privileges({"vip_level": vip_var, "td_privilege": td_var},
                    {"vip_level": VIP_OPTS, "td_privilege": TD_OPTS}, baseline, shown_baseline, privilege_dirty, latest)''')
edit('launcher.py','''        baseline.update(vip_level=player.get("vip_level", 0), td_privilege=player.get("td_privilege", 0))''','''        baseline.update(vip_level=player.get("vip_level", 0), td_privilege=player.get("td_privilege", 0))
        baseline.update({key: player.get(key, 0) for deps in PRIVILEGE_DEPENDENCIES.values() for key in deps})
        shown_baseline = editor_privilege_levels(player)
        privilege_dirty = set()''')
edit('launcher.py','''        cur_vip = int(player.get("vip_level", 0) or 0)''','''        cur_vip = shown_baseline["vip_level"]''')
edit('launcher.py','''        ttk.Combobox(vipf, textvariable=vip_var, values=VIP_OPTS, state="readonly",
                     style="Dark.TCombobox", width=8).pack(side="left", padx=8)''','''        vip_box = ttk.Combobox(vipf, textvariable=vip_var, values=VIP_OPTS, state="readonly",
                     style="Dark.TCombobox", width=8)
        vip_box.pack(side="left", padx=8)
        vip_box.bind("<<ComboboxSelected>>", lambda _event: privilege_dirty.add("vip_level"))''')
edit('launcher.py','''        cur_td = int(player.get("td_privilege", 0) or 0)''','''        cur_td = shown_baseline["td_privilege"]''')
edit('launcher.py','''        ttk.Combobox(vipf, textvariable=td_var, values=TD_OPTS, state="readonly",
                     style="Dark.TCombobox", width=6).pack(side="left", padx=8)''','''        td_box = ttk.Combobox(vipf, textvariable=td_var, values=TD_OPTS, state="readonly",
                     style="Dark.TCombobox", width=6)
        td_box.pack(side="left", padx=8)
        td_box.bind("<<ComboboxSelected>>", lambda _event: privilege_dirty.add("td_privilege"))''')
edit('launcher.py','''            values = dict(numeric)
            values.update(vip_level=VIP_OPTS.index(vip_var.get()), td_privilege=TD_OPTS.index(td_var.get()))
            fields = {key: value for key, value in values.items() if value != baseline[key]}''','''            fields = {key: value for key, value in numeric.items() if value != baseline[key]}
            fields.update(editor_privilege_fields(
                {"vip_level": VIP_OPTS.index(vip_var.get()), "td_privilege": TD_OPTS.index(td_var.get())},
                shown_baseline, privilege_dirty))''')
edit('launcher.py','''            request = {"fields": fields, "expected": {key: baseline[key] for key in fields},
                       "profile": profile_request, "profile_expected": dict(profile_baseline)}''','''            expected = {key: baseline[key] for key in fields}
            for key in fields:
                for dependency in PRIVILEGE_DEPENDENCIES.get(key, ()):
                    expected[dependency] = baseline[dependency]
            request = {"fields": fields, "expected": expected,
                       "profile": profile_request, "profile_expected": dict(profile_baseline)}''')
edit('launcher.py','''            refresh_editor_fields(ed_vars, baseline, latest)
            player.update(latest)''','''            refresh_editor_fields(ed_vars, baseline, latest)
            refresh_editor_privileges({"vip_level": vip_var, "td_privilege": td_var},
                {"vip_level": VIP_OPTS, "td_privilege": TD_OPTS}, baseline, shown_baseline, privilege_dirty, latest,
                committed=fields)
            player.update(latest)''')
edit('PvZ-Server-PoC/gm.py','''            profile_keys = [key for key in ("name", "signature") if key in profile]''','''            # UI expiry metadata is part of its optimistic snapshot: a card renewal
            # must not be overwritten just because the displayed level stayed equal.
            for key, dependencies in (("vip_level", ("vip_card_id", "vip_endtime")),
                                      ("td_privilege", ("td_privilege_endtime",))):
                if key in fields:
                    for dependency in dependencies:
                        if dependency in expected and player.get(dependency) != expected[dependency]:
                            raise ValueError("%s 已被其他操作修改，请重新核对后保存。" % dependency)
            profile_keys = [key for key in ("name", "signature") if key in profile]''')
