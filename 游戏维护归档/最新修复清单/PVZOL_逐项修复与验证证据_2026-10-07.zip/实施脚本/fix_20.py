from pathlib import Path
import hashlib,json,re,struct,zlib
from repair_tools import GAME,REPAIR
root=GAME/'webroot'
path=root/'ModuleAvatarConfig.swf'
raw=path.read_bytes()
data=zlib.decompress(raw[8:]) if raw[:3]==b'CWS' else raw[8:]
p=(5+4*(data[0]>>3)+7)//8+4
prefix=data[:p];tags=[];changes=[]
while p<len(data):
    header=struct.unpack_from('<H',data,p)[0];p+=2
    kind,size=header>>6,header&63
    if size==63:size=struct.unpack_from('<I',data,p)[0];p+=4
    payload=data[p:p+size];p+=size
    if kind==87:
        xml=payload[6:]
        def rewrite(match):
            attrs=match.group()
            avatar=int(re.search(rb'\bid="(\d+)"',attrs)[1])
            def binding(m):
                values=[]
                for value in m[2].split(b';'):
                    parts=value.split(b':')
                    if len(parts)==3 and parts[0]==b'nuts' and parts[2]:
                        target=root/'swf/battle/animation/unit'/('&'.join(x.decode() for x in parts)+'.bpart')
                        if not target.is_file():
                            changes.append({'avatar':avatar,'field':m[1].decode(),'binding':value.decode()})
                            value=b':'.join(parts[:2])+b':'
                    values.append(value)
                return m[1]+b'="'+b';'.join(values)+b'"'
            return re.sub(rb'(bbPVP|bbTD)="([^"]*)"',binding,attrs)
        xml=re.sub(rb'<a\s+[^>]+/>',rewrite,xml)
        payload=payload[:6]+xml
    tags.append(struct.pack('<H',kind<<6|63)+struct.pack('<I',len(payload))+payload)
    if kind==0:break
assert changes
body=prefix+b''.join(tags)
result=b'CWS'+raw[3:4]+struct.pack('<I',len(body)+8)+zlib.compress(body)
path.write_bytes(result)
old_alias=list(root.glob('ModuleAvatarConfig_*.swf'))
for alias in old_alias:alias.write_bytes(result)
digest=hashlib.md5(result).hexdigest()
alias=root/('ModuleAvatarConfig_'+digest+'.swf');alias.write_bytes(result)
ver=root/'fileVer.xml';text=ver.read_bytes()
text,n=re.subn(rb'<file name="ModuleAvatarConfig\.swf" size="\d+" ver="[a-f0-9]+" />',
              ('<file name="ModuleAvatarConfig.swf" size="%d" ver="%s" />'%(len(result),digest)).encode(),text)
assert n==1
ver.write_bytes(text)
files=['webroot/ModuleAvatarConfig.swf','webroot/fileVer.xml']+['webroot/'+p.name for p in old_alias]+['webroot/'+alias.name]
(REPAIR/'ready/resource-01-files.json').write_text(json.dumps(files,indent=2),encoding='utf-8')
(REPAIR/'logs/resource-01-fallbacks.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'bindings_removed':len(changes),'avatars':sorted({c['avatar'] for c in changes}),'new_version':digest}))
