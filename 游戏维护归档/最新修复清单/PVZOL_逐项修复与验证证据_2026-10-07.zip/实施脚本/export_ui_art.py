from pathlib import Path
import os,subprocess,concurrent.futures
from repair_tools import WORK,GAME
java=Path(r'C:\Users\komi\Documents\Codex\2026-09-29\new-chat-3\_work\jre\jdk-21.0.12.1+1-jre\bin\java.exe')
jar=Path(r'C:\Users\komi\Documents\Codex\2026-09-29\new-chat-3\ffdec_26.3.0\ffdec.jar')
env=os.environ.copy();env['APPDATA']=str(WORK/'ffdec-appdata')
jobs=[('star','swf/resource.swf',['-selectid','216'],'image'),('vip','swf/vip/vipUI.swf',['-selectid','56'],'image'),('talent','image/talent/ui/plantTalent_bj.swf',[],'frame')]
def export(job):
    name,source,opts,kind=job
    p=subprocess.run([str(java),'-Djava.awt.headless=true','-jar',str(jar),'-ignorebackground',*opts,'-export',kind,str(WORK/'resource-export/ui'/name),str(GAME/'webroot'/source)],env=env,capture_output=True,timeout=90)
    (WORK/'resource-export'/f'{name}-export.log').write_bytes(p.stdout+p.stderr)
    return name,p.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(export,jobs))
print(results)
assert all(code==0 for _,code in results)
