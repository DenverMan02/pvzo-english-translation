from repair_tools import edit,GAME
text=(GAME/'PvZ-Server-PoC/pvz_poc_server.py').read_text(encoding='utf-8')
start=text.index('    uid = parse_varint_fields(cmd_data).get(1, 0)',text.index('def handle_card_fasterlevelup'))
end=text.index('\n\n\n# --- card enhancement',start)
old=text[start:end]
segment=old[old.index('    total_exp, consume'):old.index('    if total_exp <= 0:')]
newseg='''    requested = {}
    for sub in parse_repeated_submessages(cmd_data, 2):
        it = parse_varint_fields(sub)
        item_id, num = (it.get(2, 0), it.get(3, 0)) if 3 in it else (it.get(1, 0), it.get(2, 0))
        if num <= 0 or not card_exp_items().get(item_id, 0):
            return []
        requested[item_id] = requested.get(item_id, 0) + num
    if any(store.get_item_count(uin, item_id) < num for item_id, num in requested.items()):
        return []
    consume = [(item_id, -num) for item_id, num in requested.items()]
    total_exp = sum(card_exp_items()[item_id] * num for item_id, num in requested.items())
'''
new=old.replace(segment,newseg)
# All inventory checks, debit and XP changes use the same refreshed account transaction.
new='    with store.atomic_player(player):\n'+''.join('    '+line if line.strip() else line for line in new.splitlines(True))
edit('PvZ-Server-PoC/pvz_poc_server.py',old,new)
