from repair_tools import edit,GAME
path=GAME/'PvZ-Server-PoC/gm.py'
text=path.read_text(encoding='utf-8')
start=text.index('        if flag:   # purchasing')
end=text.index('        print("uin=%d: diamond card',start)
old=text[start:end]
new=old.replace('player = store.get_or_create_player(uin)[0]\n            ','')
new=new.replace('print("uin=%d: need %d diamonds to purchase, have %d — abort." % (uin, COST, total))\n                return','print("uin=%d: need %d diamonds to purchase, have %d — abort." % (uin, COST, total), file=sys.stderr)\n                raise SystemExit(1)')
new='        with store.atomic_player(player):\n'+''.join('    '+line if line.strip() else line for line in new.splitlines(True))
edit('PvZ-Server-PoC/gm.py',old,new)
