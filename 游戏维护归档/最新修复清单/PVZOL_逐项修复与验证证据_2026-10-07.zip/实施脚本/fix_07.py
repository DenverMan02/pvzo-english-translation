from repair_tools import edit,GAME
edit('PvZ-Server-PoC/main_quest_local.py','''def _db():
    con = _connect()''','''def _db():
    import player_store as store
    if os.path.normcase(os.path.realpath(_db_path())) == os.path.normcase(os.path.realpath(store.DB_PATH)):
        with store._db() as con:
            con.execute(
                "CREATE TABLE IF NOT EXISTS main_quest_progress ("
                "uin INTEGER NOT NULL, quest_id INTEGER NOT NULL, "
                "curr_step INTEGER NOT NULL DEFAULT 0 CHECK(curr_step >= 0), "
                "claimed INTEGER NOT NULL DEFAULT 0 CHECK(claimed IN (0,1)), "
                "PRIMARY KEY (uin, quest_id))")
            yield con
        return
    con = _connect()''')
path=GAME/'PvZ-Server-PoC/main_quest_local.py'
old=path.read_text(encoding='utf-8')
assert old.count('        con.execute("BEGIN IMMEDIATE")')==2
new=old.replace('        con.execute("BEGIN IMMEDIATE")','        import player_store as store\n        store.begin_immediate(con)')
# The separate claim_and_grant transaction remains untouched.
edit('PvZ-Server-PoC/main_quest_local.py',old,new)
