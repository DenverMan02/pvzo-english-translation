from pathlib import Path
import json
import hashlib
import difflib
import re
import ast

WORK = Path(__file__).resolve().parent
REPAIR = WORK/'repair'
GAME = REPAIR/'game'
SERVER = GAME/'PvZ-Server-PoC'
ROOT = Path(r'D:\pvzol本地最新最新ol')

def edit(relative, old, new):
    path=GAME/relative
    raw=path.read_bytes()
    text=raw.decode('utf-8')
    pattern = re.compile(r'\r?\n'.join(re.escape(part) for part in old.split('\n')))
    matches = list(pattern.finditer(text))
    assert len(matches)==1, (relative,len(matches),old[:80])
    match = matches[0]
    ending = '\r\n' if '\r\n' in match.group() else '\n'
    if '\n' not in match.group():
        ending = '\r\n' if text.count('\r\n') > text.count('\n') / 2 else '\n'
    replacement = new.replace('\n', ending)
    path.write_bytes((text[:match.start()]+replacement+text[match.end():]).encode('utf-8'))

def ready(issue, files, tests):
    ledger=json.loads((REPAIR/'ledger.json').read_text(encoding='utf-8'))
    steps=ledger['steps']
    current=next(s for s in steps if s['status']!='deployed')
    assert current['id']==issue,(current['id'],issue)
    entries=[]
    diff=[]
    for relative in files:
        source=ROOT/'pvzol本地'/relative
        target=GAME/relative
        old=source.read_bytes() if source.exists() else b''
        new=target.read_bytes()
        if new==old:
            continue
        entries.append({'relative':'pvzol本地/'+relative,'old_sha256':hashlib.sha256(old).hexdigest() if source.exists() else None,
                        'new_sha256':hashlib.sha256(new).hexdigest(),'prepared_file':str(target)})
        if target.suffix in ('.py','.txt','.json','.xml'):
            diff.extend(difflib.unified_diff(old.decode('utf-8-sig').splitlines(True),new.decode('utf-8-sig').splitlines(True),
                                             fromfile='before/'+relative,tofile='after/'+relative))
    assert entries,'No changed files'
    (REPAIR/'ready'/f'{issue}.json').write_text(json.dumps({'issue':issue,'files':entries,'tests':tests},ensure_ascii=False,indent=2),encoding='utf-8')
    (REPAIR/'ready'/f'{issue}.diff').write_text(''.join(diff),encoding='utf-8')
    print(json.dumps({'ready':issue,'changed_files':[e['relative'] for e in entries]},ensure_ascii=False))

def atomic_handler(name):
    relative='PvZ-Server-PoC/pvz_poc_server.py'
    text=(GAME/relative).read_text(encoding='utf-8')
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name)
    body=node.body
    if isinstance(body[0],ast.Expr) and isinstance(body[0].value,ast.Constant) and isinstance(body[0].value.value,str):
        body=body[1:]
    lines=text.splitlines(True)
    old=''.join(lines[body[0].lineno-1:node.end_lineno])
    new='    with store.atomic_player(player):\n'+''.join('    '+line if line.strip() else line for line in old.splitlines(True))
    edit(relative,old,new)
