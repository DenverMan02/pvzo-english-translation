from pathlib import Path
import subprocess,os,json,re,concurrent.futures,time
work=Path(__file__).resolve().parent;repair=work/'repair';server=repair/'game/PvZ-Server-PoC'
out=repair/'logs/final';out.mkdir(exist_ok=True)
jobs=[(p.stem,p) for p in sorted((repair/'tests').glob('test_*.py'))]
old=['test_launcher_lifecycle','test_profile_editor','test_puzzle_flow','test_recycle_swap','test_vip_bulk_sweep','test_adventure_drop_chest','test_live_combat','test_captain_shield']
jobs += [(name,server/'tests'/(name+'.py')) for name in old]
env=dict(os.environ,PYTHONUTF8='1',PYTHONPATH=os.pathsep.join([str(repair/'tests'),str(server)]),PVZ_CLIENTDB=str(repair/'game/webroot/clientDB.txt'))
def run(job):
    name,path=job;started=time.monotonic()
    try:
        p=subprocess.run([os.sys.executable,'-X','utf8',str(path)],cwd=path.parent,env=env,capture_output=True,encoding='utf8',errors='replace',timeout=120)
        log=p.stdout+'\n'+p.stderr;(out/(name+'.log')).write_text(log,encoding='utf8')
        count=re.search(r'Ran (\d+) tests? in',log)
        result=dict(name=name,exit=p.returncode,tests=int(count[1]) if count else None,seconds=round(time.monotonic()-started,3),log=str(out/(name+'.log')))
    except Exception as e:result=dict(name=name,exit=-1,error=repr(e))
    print(json.dumps(result,ensure_ascii=False),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,jobs))
summary={'scripts':len(results),'passed':sum(r['exit']==0 for r in results),'failed':sum(r['exit']!=0 for r in results),'unittest_count':sum(r.get('tests') or 0 for r in results),'results':results}
(out/'results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in summary.items() if k!='results'}))
raise SystemExit(bool(summary['failed']))
