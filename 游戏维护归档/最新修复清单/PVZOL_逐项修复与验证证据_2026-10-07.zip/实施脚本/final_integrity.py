from pathlib import Path
import sqlite3,json,hashlib,socket,sys,ast
from repair_tools import ROOT,WORK,REPAIR,GAME
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ledger=json.loads((REPAIR/'ledger.json').read_text(encoding='utf8'))
assert all(s['status']=='deployed' for s in ledger['steps'])
latest={}
for s in ledger['steps']:
    manifest=json.loads((REPAIR/'ready'/(s['id']+'.json')).read_text(encoding='utf8'))
    assert (Path(s['backup'])/'change.json').exists()
    for entry in manifest['files']:latest[entry['relative']]=entry
matches=[]
for relative,entry in latest.items():
    target=ROOT/relative;match=hashfile(target)==entry['new_sha256']==hashfile(Path(entry['prepared_file']))
    matches.append({'file':relative,'matches':match});assert match,relative
unchanged=[]
for entry in json.loads((WORK/'source_manifest.json').read_text(encoding='utf8'))['files']:
    if entry['file'] not in latest:
        match=hashfile(ROOT/entry['file'])==entry['sha256'];unchanged.append({'file':entry['file'],'unchanged':match});assert match,entry['file']
syntax=[]
for p in [GAME/'launcher.py',*list((GAME/'PvZ-Server-PoC').glob('*.py'))]:
    ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p));syntax.append(p.name)
db=ROOT/'pvzol本地/PvZ-Server-PoC/players.db'
before=hashfile(db);original=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True)
integrity={'quick_check':original.execute('PRAGMA quick_check').fetchall(),'player_count':original.execute('select count(*) from players').fetchone()[0],
           'negative_basic_resources':original.execute('select count(*) from players where coin<0 or ticket<0 or present_ticket<0 or exp<0 or energy<0').fetchone()[0]}
assert integrity['quick_check']==[('ok',)]
snapshot=REPAIR/'logs/final-migration-save.db';assert not snapshot.exists()
copy=sqlite3.connect(snapshot);original.backup(copy);original.close();copy.close()
def snapshots(path,columns=None):
    con=sqlite3.connect(path)
    try:
        cols=columns or {table:[row[1] for row in con.execute('pragma table_info("'+table+'")')] for table in ('players','cards','items','plants') if con.execute('select 1 from sqlite_master where name=?',(table,)).fetchone()}
        data={table:sorted(con.execute('select '+','.join('"'+c+'"' for c in cs)+' from "'+table+'"').fetchall(),key=repr) for table,cs in cols.items()}
        return cols,{table:hashlib.sha256(repr(rows).encode()).hexdigest() for table,rows in data.items()}
    finally:con.close()
columns,old=snapshots(snapshot)
sys.path.insert(0,str(GAME/'PvZ-Server-PoC'))
import player_store as store
store.set_db_path(str(snapshot));store.init_db();store.close_thread_db()
_,new=snapshots(snapshot,columns);assert old==new,'Additive migration changed existing account/card/item/plant data'
assert hashfile(db)==before,'Original save hash changed during read-only checks'
ports={}
for port in (80,843,8080,8081,9001):
    with socket.socket() as sock:
        sock.settimeout(.3);ports[str(port)]=sock.connect_ex(('127.0.0.1',port))==0
report={'deployed_steps':len(ledger['steps']),'deployed_files':len(matches),'all_hashes_match':all(x['matches'] for x in matches),
        'unmodified_baseline_files':len(unchanged),'syntax_checked':len(syntax),'original_save':integrity,'original_save_sha256':before,
        'original_save_unchanged_during_verification':True,'isolated_migration_preserves_existing_core_data':old==new,'listening_ports':ports,
        'files':matches,'unchanged_files':unchanged}
(REPAIR/'logs/final-integrity.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k not in ('files','unchanged_files')},ensure_ascii=False))
