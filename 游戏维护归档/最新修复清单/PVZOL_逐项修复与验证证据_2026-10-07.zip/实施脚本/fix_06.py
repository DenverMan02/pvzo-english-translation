from repair_tools import edit,GAME
path=GAME/'PvZ-Server-PoC/profile_editor.py'
text=path.read_text(encoding='utf-8')
start=text.index('def save_profile(')
cut=text.index('    created = None',start)
pre=text[start:cut]
edit('PvZ-Server-PoC/profile_editor.py',pre,pre.replace('def save_profile(','def prepare_profile(')+'''    return player, root, fields, data, suffix


def save_profile(uin, request, root=None, created_paths=None):
    player, root, fields, data, suffix = prepare_profile(uin, request, root)
    name, signature = fields['name'], fields['signature']
''')
edit('PvZ-Server-PoC/profile_editor.py',"    return {'name': name, 'signature': signature,","    if created is not None and created_paths is not None:\n        created_paths.append(created)\n    return {'name': name, 'signature': signature,")
path=GAME/'PvZ-Server-PoC/gm.py'
text=path.read_text(encoding='utf-8')
start=text.index('    with store.atomic_player(player) as con:',text.index('def apply_editor_patch'))
end=text.index('\n\n\ndef validate_uin',start)
old=text[start:end]
new='''    profile = request.get("profile", {})
    profile_expected = request.get("profile_expected", {})
    if not isinstance(profile, dict) or not isinstance(profile_expected, dict):
        raise ValueError("个人资料请求不正确。")
    if set(profile) - {"name", "signature", "avatar", "image_path"}:
        raise ValueError("个人资料字段不正确。")
    created_paths = []
    try:
        with store.atomic_player(player) as con:
            for key in fields:
                if key not in expected or player.get(key) != expected[key]:
                    raise ValueError("%s 已被其他操作修改，请重新核对后保存。" % key)
            profile_keys = [key for key in ("name", "signature") if key in profile]
            if profile.get("avatar", "keep") != "keep":
                profile_keys.extend(("face_id", "qq_face_url"))
            for key in profile_keys:
                if key not in profile_expected or player.get(key) != profile_expected[key]:
                    raise ValueError("%s 已被其他操作修改，请重新核对后保存。" % key)
            if profile:
                from profile_editor import prepare_profile, save_profile
                prepare_profile(uin, profile)
            updates = dict(fields)
            if "td_privilege" in updates:
                import time
                updates["td_privilege_endtime"] = int(time.time()) + 86400 * 365 if updates["td_privilege"] else 0
            if updates:
                store.save_player(uin, **updates)
            if profile:
                save_profile(uin, profile, created_paths=created_paths)
            result = dict(con.execute("SELECT * FROM players WHERE uin=?", (uin,)).fetchone())
        return result
    except BaseException:
        for path in created_paths:
            if path.exists():
                path.unlink()
        raise'''
edit('PvZ-Server-PoC/gm.py',old,new)
edit('launcher.py',"        name_var = tk.StringVar(value=player.get(\"name\") or \"\")",'''        profile_baseline = {key: player.get(key) for key in ("name", "signature", "face_id", "qq_face_url")}
        name_var = tk.StringVar(value=player.get("name") or "")''')
edit('launcher.py',"            name_var.set(player[\"name\"])\n            signature_var.set(player[\"signature\"])","            profile_baseline.update({key: player.get(key) for key in profile_baseline})\n            name_var.set(player[\"name\"])\n            signature_var.set(player[\"signature\"])")
edit('launcher.py','''                if val.lstrip("-").isdigit():
                    numeric[key] = int(val)
            try:
                validate_player_fields(numeric)''','''                if re.fullmatch(r"[+-]?[0-9]+", val) is None:
                    status.configure(text="%s 必须是整数。" % _label, fg=STOP)
                    return
                numeric[key] = int(val)
            try:
                validate_player_fields(numeric)''')
edit('launcher.py','''            if not save_profile():
                return
            values = dict(numeric)''','''            values = dict(numeric)''')
edit('launcher.py','''            request = {"fields": fields, "expected": {key: baseline[key] for key in fields}}
            ok, out''','''            profile_request = {}
            for key, value in (("name", name_var.get()), ("signature", signature_var.get())):
                if value != (profile_baseline[key] or ""):
                    profile_request[key] = value
            mode = choices.get(avatar_var.get(), "keep")
            if mode != "keep":
                profile_request["avatar"] = mode
                if mode == "custom":
                    profile_request["image_path"] = avatar_path.get()
            request = {"fields": fields, "expected": {key: baseline[key] for key in fields},
                       "profile": profile_request, "profile_expected": dict(profile_baseline)}
            ok, out''')
edit('launcher.py','''            player.update(latest)
            status.configure(text="已保存，下次开始游戏时同步资料和设置。", fg=ACCENT)''','''            player.update(latest)
            profile_baseline.update({key: latest[key] for key in profile_baseline})
            name_var.set(latest["name"])
            signature_var.set(latest["signature"])
            avatar_var.set(current_label)
            avatar_path.set("")
            refresh_avatar()
            status.configure(text="已保存，下次开始游戏时同步资料和设置。", fg=ACCENT)''')
