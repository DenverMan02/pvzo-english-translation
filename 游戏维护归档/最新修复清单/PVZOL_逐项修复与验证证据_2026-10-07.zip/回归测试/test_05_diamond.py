import sys
import unittest
from unittest.mock import patch
from common import GameCase,store
import gm
class Diamond(GameCase):
    def invoke(self,flag=1):
        with patch.object(sys,'argv',['gm.py',str(self.p['uin']),'diamond',str(flag),'7','0','0']):gm.main()
    def test_insufficient_is_failure_and_unchanged(self):
        store.save_player(self.p['uin'],ticket=10,present_ticket=9,diamond_flag=0)
        with self.assertRaises(SystemExit) as exc:self.invoke()
        self.assertNotEqual(exc.exception.code,0)
        p=store.get_or_create_player(self.p['uin'])[0]
        self.assertEqual((p['ticket'],p['present_ticket'],p['diamond_flag']),(10,9,0))
    def test_gold_and_mixed_payment(self):
        for gold,gift in ((20,0),(10,10)):
            store.save_player(self.p['uin'],ticket=gold,present_ticket=gift,diamond_flag=0)
            self.invoke()
            p=store.get_or_create_player(self.p['uin'])[0]
            self.assertEqual((p['ticket'],p['present_ticket'],p['diamond_flag']),(0,0,1))
    def test_disable_has_no_charge(self):
        store.save_player(self.p['uin'],ticket=10,present_ticket=0)
        self.invoke(0)
        self.assertEqual(store.get_or_create_player(self.p['uin'])[0]['ticket'],10)
    def test_flag_failure_rolls_back_payment(self):
        store.save_player(self.p['uin'],ticket=20,present_ticket=0)
        original=store.save_player
        def failing(uin,**fields):
            if 'diamond_flag' in fields:raise RuntimeError('injected')
            return original(uin,**fields)
        with patch.object(store,'save_player',side_effect=failing):
            with self.assertRaises(RuntimeError):self.invoke()
        self.assertEqual(store.get_or_create_player(self.p['uin'])[0]['ticket'],20)
if __name__=='__main__':unittest.main()
