import time
import unittest
from common import GameCase,store
class QuestTransaction(GameCase):
    rows=[{'id':'1','type':'1','finishCondition':'4:0:10','reward':'1,10'}]
    def test_real_finishfill_route_completes_without_lock(self):
        self.p=self.player(level=50)
        uid=10001101
        store.add_card(self.p['uin'],uid,1101,100)
        board=self.g.load_card_puzzle()[1]
        for index in range(board['width']*board['height']):store.add_card_filled_index(self.p['uin'],uid,index)
        start=time.monotonic()
        reply=self.route('Card_FinishFill',self.g.pb_int64_field(1,uid))
        self.assertLess(time.monotonic()-start,2)
        self.assertEqual(store.get_card_fill_quality(self.p['uin'],uid),2)
        self.assertEqual(store.get_card_filled_indices(self.p['uin'],uid),[])
        self.assertTrue(any(name.endswith('Card_FinishFill_SC') for name,body in reply))
    def test_progress_joins_outer_transaction_and_rolls_back(self):
        quest=self.g.main_quest_local
        start=time.monotonic()
        with self.assertRaises(RuntimeError):
            with store.atomic_player(self.p):
                store.save_player(self.p['uin'],coin=1)
                changes=quest.set_condition_progress(self.p['uin'],self.rows,4,0,3)
                self.assertEqual(changes[0]['currStep'],3)
                raise RuntimeError('injected')
        self.assertLess(time.monotonic()-start,2)
        self.assertEqual(quest.get_list(self.p['uin'],self.rows)[0]['currStep'],0)
        self.assertNotEqual(store.get_or_create_player(self.p['uin'])[0]['coin'],1)
    def test_progress_commits_with_player_and_nested_single_quest(self):
        quest=self.g.main_quest_local
        with store.atomic_player(self.p):
            store.save_player(self.p['uin'],coin=123)
            quest.set_progress(self.p['uin'],self.rows,1,2)
        self.assertEqual(quest.get_list(self.p['uin'],self.rows)[0]['currStep'],2)
        self.assertEqual(store.get_or_create_player(self.p['uin'])[0]['coin'],123)
if __name__=='__main__':unittest.main()
