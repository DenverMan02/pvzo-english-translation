import re
from pathlib import Path
from contextlib import contextmanager
import unittest
from unittest.mock import Mock,patch
from common import GameCase,store,GAME,function
import gm
import profile_editor
class EditorAtomic(GameCase):
    def test_bad_text_stops_before_any_profile_or_gm_write(self):
        for text in ('abc','1.5','','--1'):
            status=Mock();self_ui=Mock();var=Mock();var.get.return_value=text
            f=function(GAME/'launcher.py','apply_main',{'re':re,'FIELDS':[('金币','coin')],'ed_vars':{'coin':var},'status':status,'STOP':'red','self':self_ui})
            f();self_ui._run_gm.assert_not_called()
            self.assertIn('金币',status.configure.call_args.kwargs['text'])
    def request(self,**extra):
        p=store.get_or_create_player(self.p['uin'])[0]
        return {'fields':{'coin':300,'vip_level':2},'expected':{'coin':p['coin'],'vip_level':p['vip_level']},
                'profile':{'name':'新名称','signature':'新签名'},'profile_expected':{'name':p['name'],'signature':p['signature']},**extra}
    def test_invalid_profile_keeps_currency_and_vip(self):
        before=store.get_or_create_player(self.p['uin'])[0]
        req=self.request();req['profile']['name']='一'
        with self.assertRaises(ValueError):gm.apply_editor_patch(self.p['uin'],req)
        after=store.get_or_create_player(self.p['uin'])[0]
        self.assertEqual((after['coin'],after['vip_level'],after['name']),(before['coin'],before['vip_level'],before['name']))
    def test_valid_complete_request(self):
        result=gm.apply_editor_patch(self.p['uin'],self.request())
        self.assertEqual((result['coin'],result['vip_level'],result['name'],result['signature']),(300,2,'新名称','新签名'))
    def test_profile_failure_rolls_back_previous_fields(self):
        before=store.get_or_create_player(self.p['uin'])[0]
        with patch.object(profile_editor,'save_profile',side_effect=OSError('injected')):
            with self.assertRaises(OSError):gm.apply_editor_patch(self.p['uin'],self.request())
        after=store.get_or_create_player(self.p['uin'])[0]
        self.assertEqual((after['coin'],after['vip_level']),(before['coin'],before['vip_level']))
    def test_outer_failure_removes_new_avatar(self):
        root=Path(self.folder.name)
        source=root/'avatar.png'
        source.write_bytes((GAME/'webroot/image/head/2.png').read_bytes())
        req=self.request()
        req['profile'].update(avatar='custom',image_path=str(source))
        req['profile_expected'].update(face_id=self.p['face_id'],qq_face_url=self.p['qq_face_url'])
        original=store.atomic_player
        @contextmanager
        def failing(player):
            depth=getattr(store._THREAD_STATE,'atomic_depth',0)
            with original(player) as con:
                yield con
                if depth==0:raise RuntimeError('commit interrupted')
        with patch.object(profile_editor,'GAME_ROOT',root),patch.object(store,'atomic_player',failing):
            with self.assertRaises(RuntimeError):gm.apply_editor_patch(self.p['uin'],req)
        self.assertEqual(list((root/'webroot/image/head/custom').glob('*')),[])
        self.assertNotEqual(store.get_or_create_player(self.p['uin'])[0]['coin'],300)
if __name__=='__main__':unittest.main()
