import time
import unittest
from unittest.mock import patch
from common import GameCase,store
class Energy(GameCase):
    def setUp(self):
        super().setUp();self.p=self.player(level=100,energy=0,energy_time=int(time.time()))
        self.g.ensure_player_cards(self.p)
        self.req=self.g.pb_bytes(1,b''.join(self.g.pb_varint_field(f,1) for f in (1,2,3,4)))
    def test_no_energy_cannot_fight_or_reward(self):
        before=store.get_or_create_player(self.p['uin'])[0]
        with patch.object(self.g,'run_battle') as run:
            reply=self.route('Battle_Fight',self.req)
            run.assert_not_called()
        self.assertTrue(any('Error' in name for name,body in reply))
        after=store.get_or_create_player(self.p['uin'])[0]
        self.assertEqual((after['coin'],after['exp'],after['energy']),(before['coin'],before['exp'],0))
        self.assertFalse(store.get_fuben_passed(self.p['uin'],1,1))
    def test_affordable_attempt_spends_configured_energy(self):
        self.p=self.player(level=100,energy=10,energy_time=int(time.time()))
        with patch.object(self.g,'run_battle',return_value=(False,0,0,[])):
            reply=self.route('Battle_Fight',self.req)
        self.assertEqual(store.get_or_create_player(self.p['uin'])[0]['energy'],10-self.g.fuben_energy_cost(1,1,1))
        self.assertTrue(any(name.endswith('Battle_Fight_SC') for name,body in reply))
    def test_failed_battle_restores_energy(self):
        self.p=self.player(level=100,energy=10,energy_time=int(time.time()))
        with patch.object(self.g,'run_battle',side_effect=RuntimeError('injected')):
            with self.assertRaises(RuntimeError):self.route('Battle_Fight',self.req)
        self.assertEqual(store.get_or_create_player(self.p['uin'])[0]['energy'],10)
if __name__=='__main__':unittest.main()
