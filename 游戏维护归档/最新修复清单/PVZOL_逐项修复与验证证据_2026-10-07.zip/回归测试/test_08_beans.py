import unittest
from unittest.mock import patch
from common import GameCase,store
class Beans(GameCase):
    def setUp(self):
        super().setUp();self.p=self.player(level=50);self.uid=10001101
        store.add_card(self.p['uin'],self.uid,1101,1)
    def request(self,entries):
        return self.g.pb_int64_field(1,self.uid)+b''.join(self.g.pb_bytes(2,self.g.pb_varint_field(a,2002)+self.g.pb_varint_field(b,n)) for a,b,n in entries)
    def test_duplicate_overstock_rejected(self):
        store.add_item(self.p['uin'],2002,1)
        self.route('Card_FasterLevelUp',self.request([(1,2,1),(1,2,1)]))
        self.assertEqual(store.get_cards(self.p['uin'])[0][3],0)
        self.assertEqual(store.get_item_count(self.p['uin'],2002),1)
    def test_duplicate_aggregate_and_legacy(self):
        store.add_item(self.p['uin'],2002,3)
        self.route('Card_FasterLevelUp',self.request([(1,2,1),(1,2,1)]))
        self.assertEqual(store.get_cards(self.p['uin'])[0][3],20000)
        self.route('Card_FasterLevelUp',self.request([(2,3,1)]))
        self.assertEqual(store.get_cards(self.p['uin'])[0][3],30000)
        self.assertEqual(store.get_item_count(self.p['uin'],2002),0)
    def test_failed_exp_update_rolls_back_bean(self):
        store.add_item(self.p['uin'],2002,1)
        with patch.object(self.g,'add_card_exp',side_effect=RuntimeError('injected')):
            with self.assertRaises(RuntimeError):self.route('Card_FasterLevelUp',self.request([(1,2,1)]))
        self.assertEqual(store.get_item_count(self.p['uin'],2002),1)
if __name__=='__main__':unittest.main()
