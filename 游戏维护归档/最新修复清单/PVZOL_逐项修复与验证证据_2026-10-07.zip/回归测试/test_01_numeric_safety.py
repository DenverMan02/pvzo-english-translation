import ast
import re
import subprocess
import sys
import unittest
from unittest.mock import Mock, patch
from common import GameCase, store, SERVER, GAME, function
import gm

class NumericSafety(GameCase):
    def test_negative_varint_fails_promptly_and_preserves_uint64(self):
        code=('import ast;from pathlib import Path;'
              f't=ast.parse(Path({str(SERVER/"pvz_poc_server.py")!r}).read_text(encoding="utf-8"));'
              'n=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=="uvarint");'
              'd={};exec(compile(ast.Module(body=[n],type_ignores=[]),"encoding","exec"),d);d["uvarint"](-1)')
        try:
            p=subprocess.run([sys.executable,'-X','utf8','-c',code],capture_output=True,text=True,timeout=1)
        except subprocess.TimeoutExpired:
            self.fail('uvarint(-1) did not reject the invalid value')
        self.assertNotEqual(p.returncode,0)
        self.assertIn('ValueError',p.stderr)
        self.assertEqual(self.g.uvarint(0),b'\x00')
        self.assertEqual(self.g.uvarint(2**32),b'\x80\x80\x80\x80\x10')
        self.assertEqual(len(self.g.uvarint(2**63-1)),9)
    def test_generic_gm_invalid_batch_does_not_partially_save(self):
        before=store.get_or_create_player(self.p['uin'])[0]
        with patch.object(sys,'argv',['gm.py',str(self.p['uin']),'coin','200','sun','-1']):
            with self.assertRaises(SystemExit) as error:
                gm.main()
        self.assertNotEqual(error.exception.code,0)
        after=store.get_or_create_player(self.p['uin'])[0]
        self.assertEqual((after['coin'],after['sun']),(before['coin'],before['sun']))
    def test_uint32_and_actual_level_boundaries(self):
        gm.validate_player_fields({'level':200,'coin':4294967295,'energy':10000})
        for fields in ({'level':0},{'level':201},{'coin':-1},{'ticket':4294967296}):
            with self.assertRaises(ValueError):gm.validate_player_fields(fields)
    def test_editor_rejects_negative_before_profile_or_settings_write(self):
        class Var:
            def __init__(self,value):self.value=value
            def get(self):return self.value
        save_profile=Mock(return_value=True)
        app=Mock()
        namespace=dict(re=re,save_profile=save_profile,uin=str(self.p['uin']),FIELDS=[('金币','coin')],
                       ed_vars={'coin':Var('-1')},self=app,status=Mock(),ACCENT='ok',STOP='bad',
                       VIP_OPTS=['无'],vip_var=Var('无'),TD_OPTS=['无'],td_var=Var('无'))
        function(GAME/'launcher.py','apply_main',namespace)()
        save_profile.assert_not_called()
        app._run_gm.assert_not_called()

if __name__=='__main__':unittest.main()
