import unittest
from common import GameCase,store,launcher
import gm

class Var:
    def __init__(self,value):self.value=str(value)
    def get(self):return self.value
    def set(self,value):self.value=str(value)

class EditorConflict(GameCase):
    def test_refresh_preserves_dirty_fields(self):
        mod=launcher()
        variables={'ticket':Var(100),'coin':Var(999)}
        baseline={'ticket':100,'coin':100}
        mod.refresh_editor_fields(variables,baseline,{'ticket':80,'coin':200})
        self.assertEqual(variables['ticket'].get(),'80')
        self.assertEqual(variables['coin'].get(),'999')
        self.assertEqual(baseline,{'ticket':80,'coin':100})
    def test_only_changed_fields_apply_and_other_wallet_survives(self):
        store.save_player(self.p['uin'],ticket=80,coin=100)
        result=gm.apply_editor_patch(self.p['uin'],{'fields':{'coin':300},'expected':{'coin':100}})
        self.assertEqual((result['ticket'],result['coin']),(80,300))
    def test_conflict_rejects_whole_batch(self):
        store.save_player(self.p['uin'],coin=200,sun=10)
        with self.assertRaises(ValueError):
            gm.apply_editor_patch(self.p['uin'],{'fields':{'coin':300,'sun':50},'expected':{'coin':100,'sun':10}})
        latest=store.get_or_create_player(self.p['uin'])[0]
        self.assertEqual((latest['coin'],latest['sun']),(200,10))

if __name__=='__main__':unittest.main()
