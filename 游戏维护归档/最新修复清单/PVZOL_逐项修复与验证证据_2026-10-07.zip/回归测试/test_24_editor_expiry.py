import json,re,time,os,unittest
from pathlib import Path
from unittest.mock import Mock
from common import GameCase,store,launcher,function,GAME
import gm

class Var:
    def __init__(self,value):self.value=str(value)
    def get(self):return self.value
    def set(self,value):self.value=str(value)

class EditorExpiry(GameCase):
    def form(self,player):
        mod=launcher();baseline={'coin':player['coin'],'vip_level':player['vip_level'],'td_privilege':player['td_privilege']}
        for deps in mod.PRIVILEGE_DEPENDENCIES.values():baseline.update({k:player[k] for k in deps})
        shown=mod.editor_privilege_levels(player);dirty=set();requests=[]
        ui=Mock()
        def apply(args):
            request=json.loads(args[2]);requests.append(request)
            try:return True,json.dumps(gm.apply_editor_patch(int(args[0]),request))
            except ValueError as e:return False,str(e)
        ui._run_gm.side_effect=apply
        ns=dict(re=re,FIELDS=[('金币','coin')],ed_vars={'coin':Var(player['coin'])},baseline=baseline,shown_baseline=shown,
                privilege_dirty=dirty,VIP_OPTS=['关闭','VIP1','VIP2','VIP3'],TD_OPTS=['关闭','开启'],
                vip_var=Var(['关闭','VIP1','VIP2','VIP3'][shown['vip_level']]),td_var=Var(['关闭','开启'][shown['td_privilege']]),
                profile_baseline={k:player[k] for k in ('name','signature','face_id','qq_face_url')},
                name_var=Var(player['name']),signature_var=Var(player['signature'] or ''),choices={'current':'keep'},avatar_var=Var('current'),
                avatar_path=Var(''),current_label='current',uin=str(player['uin']),self=ui,json=json,status=Mock(),
                STOP='red',ACCENT='green',player=player,refresh_avatar=Mock(),
                refresh_editor_fields=mod.refresh_editor_fields,refresh_editor_privileges=mod.refresh_editor_privileges,
                editor_privilege_fields=mod.editor_privilege_fields,PRIVILEGE_DEPENDENCIES=mod.PRIVILEGE_DEPENDENCIES)
        source=Path(os.environ.get('PVZ_EDITOR_SOURCE',str(GAME/'launcher.py')))
        callback=function(source,'apply_main',ns)
        return callback,ns,requests
    def expired(self):return self.player(vip_level=2,vip_card_id=5,vip_endtime=1,td_privilege=1,td_privilege_endtime=1)
    def test_unedited_expired_rights_do_not_change_while_currency_saves(self):
        p=self.expired();apply,ns,requests=self.form(p)
        self.assertEqual((ns['vip_var'].get(),ns['td_var'].get()),('关闭','关闭'))
        ns['ed_vars']['coin'].set(p['coin']+1);apply()
        self.assertEqual(set(requests[0]['fields']),{'coin'})
        saved,_=store.get_or_create_player(p['uin'])
        self.assertEqual((saved['vip_card_id'],saved['vip_endtime'],saved['td_privilege_endtime']),(5,1,1))
    def test_same_original_level_can_reactivate_expired_rights_in_real_callback(self):
        p=self.expired();apply,ns,requests=self.form(p)
        ns['vip_var'].set('VIP2');ns['td_var'].set('开启');apply()
        saved,_=store.get_or_create_player(p['uin'])
        self.assertEqual((saved['vip_level'],saved['vip_card_id'],saved['vip_endtime']),(2,0,0))
        self.assertTrue(self.g.td_privilege_active(saved));self.assertEqual(self.g.active_vip_level(saved),2)
        self.assertEqual(requests[0]['expected']['vip_level'],2)
        self.assertEqual(requests[0]['expected']['vip_endtime'],1)
        self.assertEqual(ns['baseline']['vip_endtime'],0)
    def test_explicit_same_active_level_selection_can_set_permanent_vip(self):
        p=self.player(vip_level=2,vip_card_id=5,vip_endtime=int(time.time())+1000)
        apply,ns,requests=self.form(p);ns['privilege_dirty'].add('vip_level');apply()
        self.assertEqual(store.get_or_create_player(p['uin'])[0]['vip_card_id'],0)
        self.assertIn('vip_level',requests[0]['fields']);self.assertEqual(ns['privilege_dirty'],set())
    def test_external_renewal_conflict_preserves_new_card_and_entire_currency_batch(self):
        p=self.expired();before_coin=p['coin'];apply,ns,requests=self.form(p)
        ns['vip_var'].set('VIP2');ns['ed_vars']['coin'].set(before_coin+50)
        new_end=int(time.time())+2000;store.save_player(p['uin'],vip_endtime=new_end)
        apply();saved,_=store.get_or_create_player(p['uin'])
        self.assertEqual((saved['vip_card_id'],saved['vip_endtime'],saved['coin']),(5,new_end,before_coin))
        self.assertIn('vip_endtime',ns['status'].configure.call_args.kwargs['text'])
    def test_refresh_clean_display_keeps_real_snapshot_and_preserves_dirty_snapshot(self):
        p=self.expired();_,ns,_=self.form(p);mod=launcher()
        variables={'vip_level':ns['vip_var'],'td_privilege':ns['td_var']};options={'vip_level':ns['VIP_OPTS'],'td_privilege':ns['TD_OPTS']}
        latest=dict(p,vip_endtime=int(time.time())+1000)
        mod.refresh_editor_privileges(variables,options,ns['baseline'],ns['shown_baseline'],ns['privilege_dirty'],latest)
        self.assertEqual(ns['vip_var'].get(),'VIP2');self.assertEqual(ns['baseline']['vip_level'],2)
        ns['privilege_dirty'].add('vip_level');ns['vip_var'].set('VIP3')
        mod.refresh_editor_privileges(variables,options,ns['baseline'],ns['shown_baseline'],ns['privilege_dirty'],dict(latest,vip_endtime=latest['vip_endtime']+500))
        self.assertEqual(ns['vip_var'].get(),'VIP3');self.assertEqual(ns['baseline']['vip_endtime'],latest['vip_endtime'])
    def test_legacy_permanent_flags_display_as_active(self):
        levels=launcher().editor_privilege_levels({'vip_level':3,'vip_card_id':0,'vip_endtime':0,'td_privilege':1,'td_privilege_endtime':0})
        self.assertEqual(levels,{'vip_level':3,'td_privilege':1})

if __name__=='__main__':unittest.main()
