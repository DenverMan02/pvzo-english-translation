import unittest
from common import GameCase
class SelfCostShield(GameCase):
    def test_all_chili_tiers_clear_shield_and_encode_delta(self):
        def unit(pos,**kw):
            return dict(pos=pos,card_id=101,hp=10000,atk=100,def_=0,ability=0,skill1=51,skill2=0,is_leader=False,level=1,power=100,**kw)
        for skill in range(5901,5906):
            left=unit(3);left.update(skill1=skill,initial_hp=6000,shield=400)
            right=unit(4);right.update(atk=1,hp=100000)
            state={}
            rounds=self.g.simulate_battle([left],[right],True,result_state=state,max_rounds=1)
            event=next(d for actions,_ in rounds for a in actions if a['skill']==skill for d in a['damages'] if d['target']==3 and d['dmg']>0)
            self.assertEqual(event.get('change_shield'),-400)
            self.assertEqual(state['shield'][3],0)
            self.assertGreater(state['hp'][3],0)
            wire=self.g.encode_fight_replay(rounds)
            events=[self.g.parse_varint_fields(d) for r in self.g.parse_repeated_submessages(wire,4) for a in self.g.parse_repeated_submessages(r,2) for d in self.g.parse_repeated_submessages(a,2)]
            cost=next(e for e in events if e[1]==3 and e.get(2,0)>2**63)
            self.assertEqual(cost[6]-2**64,-400)
if __name__=='__main__':unittest.main()
