import time
import unittest
from unittest.mock import patch
from common import GameCase,store
class Consumables(GameCase):
    def test_existing_chest_and_unsupported_item(self):
        iid=next(iter(self.g.load_chest_index()))
        self.give(iid);reply=self.use(iid)
        self.assertEqual(store.get_item_count(self.p['uin'],iid),0)
        self.assertTrue(any(name.endswith('Item_OpenChest_SC') for name,body in reply))
        self.give(2002)
        before=store.get_item_count(self.p['uin'],2002)
        self.assertEqual(self.use(2002),[self.g._logic_error(902)])
        self.assertEqual(store.get_item_count(self.p['uin'],2002),before)
    def use(self,iid,count=1):
        return self.route('Item_Use',self.g.pb_varint_field(1,iid)+self.g.pb_varint_field(2,count))
    def give(self,iid,count=1):store.add_item(self.p['uin'],iid,count)
    def test_energy_actual_consumption_and_nonmulti(self):
        self.p=self.player(energy=10,energy_time=int(time.time()))
        self.give(2015,2);reply=self.use(2015,2)
        self.assertEqual(self.p['energy'],30)
        self.assertEqual(store.get_item_count(self.p['uin'],2015),1)
        self.assertEqual(self.g.parse_varint_fields(reply[-1][1])[2],1)
        self.use(2015);self.use(2015)
        self.assertEqual(self.p['energy'],50)
    def test_td_days_stack_and_expire(self):
        self.give(5013);self.give(5014)
        now=int(time.time());self.use(5013);self.use(5014)
        self.assertAlmostEqual(self.p['td_privilege_endtime']-now,37*86400,delta=2)
        with patch('time.time',return_value=self.p['td_privilege_endtime']+1):self.assertFalse(self.g.td_privilege_active(self.p))
    def test_golden_level_gate_and_pool_sync(self):
        self.p=self.player(level=21);self.give(60000)
        self.assertEqual(self.use(60000),[self.g._logic_error(200)])
        self.assertEqual(store.get_item_count(self.p['uin'],60000),1)
        self.p=self.player(level=22);reply=self.use(60000)
        self.assertEqual(self.p['nutrition_gold'],1)
        body=next(body for name,body in reply if name.endswith('Nutrition_GetTempBag_SC'))
        self.assertEqual(self.g.parse_varint_fields(body)[4],1)
    def test_puppet_level_gate_real_unlock_duplicate_and_legacy(self):
        self.p=self.player(level=54);self.give(96001,2)
        self.assertEqual(self.use(96001),[self.g._logic_error(200)])
        self.p=self.player(level=55);self.use(96001,2)
        self.assertTrue(store.get_puppet(self.p['uin'],1000001))
        self.assertEqual(store.get_item_count(self.p['uin'],95601),20)
        self.give(97001);self.use(97001)
        self.assertEqual(store.get_item_count(self.p['uin'],95601),40)
    def test_vip_template_exclusion_expiry_and_legacy_permanent(self):
        self.give(5001,2);now=int(time.time());reply=self.use(5001)
        self.assertEqual((self.p['vip_card_id'],self.p['vip_level']),(4,1))
        self.assertAlmostEqual(self.p['vip_endtime']-now,30*86400,delta=2)
        info=next(body for name,body in reply if name.endswith('VipInfo_SC'))
        info=self.g.parse_varint_fields(self.g.parse_repeated_submessages(info,1)[0])
        self.assertEqual((info[1],info[2],info[6]),(4,self.p['vip_endtime'],2))
        self.assertEqual(self.use(5001),[self.g._logic_error(5101)])
        self.assertEqual(store.get_item_count(self.p['uin'],5001),1)
        with patch('time.time',return_value=self.p['vip_endtime']+1):
            self.assertEqual(self.g.vip_privileges(self.p),{})
            self.assertEqual(self.g.active_vip_level(self.p),0)
        self.p=self.player(vip_level=3,vip_card_id=0,vip_endtime=0)
        self.assertEqual(self.g.active_vip_level(self.p),3)
        self.assertEqual(self.use(5001),[self.g._logic_error(5101)])
    def test_failed_debit_rolls_back_effect(self):
        self.p=self.player(energy=10,energy_time=int(time.time()));self.give(2015)
        with patch.object(self.g,'grant_items',side_effect=RuntimeError('injected')):
            with self.assertRaises(RuntimeError):self.use(2015)
        self.assertEqual(self.p['energy'],10)
        self.assertEqual(store.get_item_count(self.p['uin'],2015),1)
if __name__=='__main__':unittest.main()
