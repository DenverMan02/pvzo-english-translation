import unittest
from common import GameCase,store
class LabSecondary(GameCase):
    def test_four_secondary_labs_change_effective_stats_in_correct_units(self):
        self.p=self.player(level=50,coin=100000)
        uid=10001101
        store.add_card(self.p['uin'],uid,1101,1)
        before=self.g.effective_card_stats(self.p,1101,1,uid=uid)
        self.route('Lab_GetLabInfo')
        for lab in (5,6,7,8):
            self.route('Lab_ProduceLab',self.g.pb_varint_field(1,lab))
            self.route('Lab_UpgradeLab',self.g.pb_varint_field(1,lab))
        after=self.g.effective_card_stats(self.p,1101,1,uid=uid)
        for key in ('hit','dodge','critical','tough'):
            self.assertEqual(after[key]-before[key],20)
        bonus=self.g.lab_stat_bonus(self.p)
        self.assertEqual(bonus['atk'],0)
if __name__=='__main__':unittest.main()
