import hashlib,re,struct,zlib,unittest
from common import GameCase,GAME
class NutsResources(GameCase):
    def test_same_plant_bindings_never_request_missing_parts(self):
        root=GAME/'webroot';raw=(root/'ModuleAvatarConfig.swf').read_bytes()
        data=zlib.decompress(raw[8:]);self.assertEqual(struct.unpack('<I',raw[4:8])[0],len(data)+8)
        entries=re.findall(rb'<a\s+[^>]+/>',data)
        found=0
        for row in entries:
            for binding in re.findall(rb'(?:bbPVP|bbTD)="([^"]*)"',row):
                for part in binding.split(b';'):
                    fields=part.split(b':')
                    if fields[0]==b'nuts':
                        found+=1
                        self.assertEqual(len(fields),3)
                        if fields[2]:self.assertTrue((root/'swf/battle/animation/unit'/('&'.join(f.decode() for f in fields)+'.bpart')).is_file(),part)
        self.assertGreater(found,0)
        self.assertTrue((root/'swf/battle/animation/unit/nuts.bbone').is_file())
    def test_hash_alias_and_version_match_actual_payload(self):
        root=GAME/'webroot';raw=(root/'ModuleAvatarConfig.swf').read_bytes();md5=hashlib.md5(raw).hexdigest()
        self.assertEqual((root/('ModuleAvatarConfig_'+md5+'.swf')).read_bytes(),raw)
        text=(root/'fileVer.xml').read_text(encoding='utf-8')
        self.assertIn('name="ModuleAvatarConfig.swf" size="%d" ver="%s"'%(len(raw),md5),text)
if __name__=='__main__':unittest.main()
