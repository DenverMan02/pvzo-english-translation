import unittest
from unittest.mock import patch
from common import GameCase,store
class Welfare(GameCase):
    def setUp(self):
        super().setUp();self.p=self.player(level=20)
        self.req=self.g.pb_varint_field(1,4)+self.g.pb_varint_field(2,20)
    def test_two_stale_sessions_receive_only_once(self):
        a=dict(self.p);b=dict(self.p)
        self.route('Welfare_Take',self.req,a)
        self.route('Welfare_Take',self.req,b)
        self.assertEqual(store.get_item_count(self.p['uin'],2002),5)
    def test_reward_failure_does_not_consume_claim(self):
        with patch.object(self.g,'grant_fuben_reward',side_effect=RuntimeError('injected')):
            with self.assertRaises(RuntimeError):self.route('Welfare_Take',self.req)
        self.route('Welfare_Take',self.req)
        self.assertEqual(store.get_item_count(self.p['uin'],2002),5)
if __name__=='__main__':unittest.main()
