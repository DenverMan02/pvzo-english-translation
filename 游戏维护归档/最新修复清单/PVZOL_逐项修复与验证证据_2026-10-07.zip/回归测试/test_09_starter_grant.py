import unittest
from common import GameCase,store
class StarterGrant(GameCase):
    def test_recycle_then_getpackage_does_not_regenerate(self):
        self.p=self.player(level=50)
        self.g.ensure_player_cards(self.p)
        uid=10001101
        self.route('Card_Recycle',self.g.pb_int64_field(1,uid))
        first=store.get_item_count(self.p['uin'],51100)
        self.assertGreater(first,0)
        for cycle in range(3):
            self.route('Card_GetPackage')
            self.assertFalse(store.has_card(self.p['uin'],uid))
            self.route('Card_Recycle',self.g.pb_int64_field(1,uid))
        self.assertEqual(store.get_item_count(self.p['uin'],51100),first)
    def test_old_progress_preserved_and_new_unlock_gets_one_card(self):
        store.add_card(self.p['uin'],1101,1101,70,999999)
        self.g.ensure_player_cards(self.p)
        self.assertIn((1101,1101,70,999999),store.get_cards(self.p['uin']))
        store.unlock_plant(self.p['uin'],1400)
        self.g.ensure_player_cards(self.p)
        cards=[c for c in store.get_cards(self.p['uin']) if c[1]==1401]
        self.assertEqual(len(cards),1)
        store.remove_card(self.p['uin'],cards[0][0])
        self.g.ensure_player_cards(self.p)
        self.assertFalse(any(c[1]==1401 for c in store.get_cards(self.p['uin'])))
if __name__=='__main__':unittest.main()
