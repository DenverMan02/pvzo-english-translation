import unittest
from unittest.mock import patch
from common import GameCase
class RankQuota(GameCase):
    def test_quota_returns_error_and_does_not_count_daily_quest(self):
        data=self.g._arena_state(self.p,'rank_arena_data')
        data['challenges']=10
        self.g._save_json_state(self.p,'rank_arena_data',data)
        with patch.object(self.g,'_daily_quest_touch') as touch,patch.object(self.g,'run_battle') as run:
            reply=self.route('RankArena_Challenge')
            touch.assert_not_called();run.assert_not_called()
        self.assertEqual(reply,[self.g._logic_error(7705)])
if __name__=='__main__':unittest.main()
