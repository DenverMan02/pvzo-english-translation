import unittest
from unittest.mock import patch
from common import GameCase,store
class BeadWallet(GameCase):
    def test_stale_session_charges_each_package(self):
        self.p=self.player(ticket=20,present_ticket=0)
        a=dict(self.p);b=dict(self.p)
        self.route('Equip_BuyBead',player=a)
        self.route('Equip_BuyBead',player=b)
        self.assertEqual(store.get_or_create_player(self.p['uin'])[0]['ticket'],0)
        self.assertEqual(store.get_item_count(self.p['uin'],2046),12)
        self.route('Equip_BuyBead',player=b)
        self.assertEqual(store.get_item_count(self.p['uin'],2046),12)
    def test_grant_failure_rolls_back_wallet(self):
        self.p=self.player(ticket=20,present_ticket=0)
        with patch.object(self.g,'grant_items',side_effect=RuntimeError('injected')):
            with self.assertRaises(RuntimeError):self.route('Equip_BuyBead')
        self.assertEqual(store.get_or_create_player(self.p['uin'])[0]['ticket'],20)
if __name__=='__main__':unittest.main()
