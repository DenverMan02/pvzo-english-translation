import time
import unittest
from common import GameCase,store
class GuildCapacity(GameCase):
    def test_two_pending_approvals_cannot_exceed_last_seat(self):
        guild=self.g.guild_local
        with guild._db() as con:
            gid=con.execute('INSERT INTO local_guilds(name,created_at) VALUES(?,?)',('test guild',int(time.time()))).lastrowid
            row=guild._guild(con,gid)
            limit=guild._member_limit(row)
            guild._add_member(con,row,self.p,position=1)
        for i in range(limit-2):
            p=self.player(820000000+i)
            with guild._db() as con:guild._add_member(con,guild._guild(con,gid),p)
        applicants=[self.player(830000001),self.player(830000002)]
        for p in applicants:self.route('GuildJoinReq',self.g.pb_varint_field(1,gid),p)
        replies=[]
        for p in applicants:
            replies.append(self.route('GuildAckJoin',self.g.pb_int64_field(1,p['role_id'])+self.g.pb_bool(2,True),self.p))
        with guild._db() as con:
            self.assertEqual(con.execute('SELECT count(*) FROM local_guild_members WHERE guild_id=?',(gid,)).fetchone()[0],limit)
            self.assertIsNone(guild._member(con,applicants[1]['uin']))
        self.assertEqual(replies[1],guild._logic_error(5008))
if __name__=='__main__':unittest.main()
