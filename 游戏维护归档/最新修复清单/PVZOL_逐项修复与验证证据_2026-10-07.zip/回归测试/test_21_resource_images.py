import hashlib,io,json,struct,zlib,unittest,tempfile,threading,http.server,urllib.request
from pathlib import Path
from PIL import Image
from common import GAME,BASE
import serve_client

class Resources(unittest.TestCase):
    def setUp(self):
        self.root=GAME/'webroot'
        self.manifest=json.loads((self.root/'resource-repair-manifest.json').read_text(encoding='utf8'))
        self.assets=self.manifest['assets']
    def test_all_actual_missing_routes_have_visible_crc_valid_images(self):
        review=json.loads((BASE.parent/'review_resources.json').read_text(encoding='utf8'))['bug21']['assets']
        self.assertEqual({a['path'] for a in review},{a['path'] for a in self.assets})
        self.assertEqual(len(self.assets),52)
        for a in self.assets:
            with self.subTest(path=a['path']):
                raw=(self.root/a['path'].lstrip('/')).read_bytes()
                self.assertEqual(hashlib.sha256(raw).hexdigest(),a['sha256'])
                self.assertEqual(raw[:8],b'\x89PNG\r\n\x1a\n')
                p=8;ended=False
                while p<len(raw):
                    n=struct.unpack_from('>I',raw,p)[0];kind=raw[p+4:p+8];body=raw[p+8:p+8+n]
                    crc=struct.unpack_from('>I',raw,p+8+n)[0]
                    self.assertEqual(zlib.crc32(kind+body)&0xffffffff,crc)
                    p+=12+n
                    if kind==b'IEND':ended=True;break
                self.assertTrue(ended);self.assertEqual(p,len(raw))
                im=Image.open(io.BytesIO(raw)).convert('RGBA');im.load()
                self.assertNotEqual(im.size,(1,1));self.assertEqual(list(im.size),a['size'])
                self.assertIsNotNone(im.getbbox());self.assertGreater(im.getchannel('A').getextrema()[1],0)
                self.assertGreater(len(set(im.getdata())),2)
                self.assertTrue(a['meaning']);self.assertTrue(a['dimension_evidence'])
    def test_geometry_preserves_inner_content_and_control_bounds(self):
        def image(path):return Image.open(self.root/path).convert('RGBA')
        for path,size in [('image/card/VIP_TIP_BG.png',(194,69)),('image/talent/ui/talentBJ.png',(56,46)),
                          ('image/puzzle/ICON.png',(24,24)),('swf/fuben/union_fuben_bk.png',(364,44)),
                          ('swf/fuben/union_fuben_curStage.png',(29,46)),('image/ui/armyInfo.png',(12,12))]:
            self.assertEqual(image(path).size,size)
        for a in self.assets:
            if '/feature/' in a['path'] or '/skill/' in a['path']:self.assertEqual(a['size'],[25,25])
            if '/feature_bg/' in a['path']:self.assertEqual(a['size'],[27,27])
        frame=image('image/puzzle/PUZZLE_FRAME.png')
        self.assertEqual(frame.size,(423,352));self.assertIsNone(frame.crop((9,7,414,345)).getbbox())
        rect=image('swf/fuben/icon_rect.png')
        self.assertEqual(rect.size,(60,60));self.assertIsNone(rect.crop((7,7,53,53)).getbbox())
        border=image('image/item/ui/borderWhite.png');self.assertEqual(border.getpixel((25,25))[3],0)
    def test_http_returns_real_files_for_every_actual_path_and_query(self):
        with tempfile.TemporaryDirectory(dir=BASE/'logs') as folder:
            serve_client.CLIENT_DIR=str(self.root);serve_client.ASSET_ERROR_LOG=str(Path(folder)/'errors.log')
            class Quiet(serve_client.Handler):
                def log_message(self,*args):pass
            server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Quiet)
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            try:
                for a in self.assets:
                    with self.subTest(path=a['path']):
                        with urllib.request.urlopen('http://127.0.0.1:%d%s?v=repair21'%(server.server_port,a['path']),timeout=4) as res:
                            body=res.read();self.assertEqual(res.status,200);self.assertEqual(res.headers.get_content_type(),'image/png')
                        self.assertEqual(body,(self.root/a['path'].lstrip('/')).read_bytes())
                        self.assertNotEqual(body,serve_client.PLACEHOLDER_PNG)
                self.assertFalse(Path(serve_client.ASSET_ERROR_LOG).exists(),'A route still fell back')
            finally:server.shutdown();server.server_close();thread.join(timeout=3)

if __name__=='__main__':unittest.main()
