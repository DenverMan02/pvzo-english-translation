import sys
import unittest
from unittest.mock import patch
from common import GameCase, store
import gm

class CardLevel(GameCase):
    def setUp(self):
        super().setUp()
        store.save_player(self.p['uin'],level=200)
        store.add_card(self.p['uin'],101,1201,20,500)
        store.add_card(self.p['uin'],102,1301,15,300)
    def invoke(self,level):
        with patch.object(sys,'argv',['gm.py',str(self.p['uin']),'cardlevel',str(level)]):
            gm.main()
    def test_unknown_target_preserves_every_card(self):
        before=store.get_cards(self.p['uin'])
        for value in (0,-1,301,999):
            with self.assertRaises(SystemExit) as exc:
                self.invoke(value)
            self.assertNotEqual(exc.exception.code,0)
            self.assertEqual(store.get_cards(self.p['uin']),before)
    def test_valid_target_uses_real_curve(self):
        self.invoke(10)
        total=next(t for lv,t,n in self.g._CARD_LEVEL_CURVE if lv==10)
        for uid,cid,lv,exp in store.get_cards(self.p['uin']):
            self.assertEqual((lv,exp),self.g.card_level_from_exp(total,cid,200))
    def test_batch_rolls_back_on_second_card_failure(self):
        before=store.get_cards(self.p['uin'])
        original=store.set_card_level
        def failing(uin,uid,lv,exp):
            if uid==102: raise RuntimeError('injected failure')
            return original(uin,uid,lv,exp)
        with patch.object(store,'set_card_level',side_effect=failing):
            with self.assertRaises(RuntimeError): self.invoke(10)
        self.assertEqual(store.get_cards(self.p['uin']),before)

if __name__=='__main__': unittest.main()
