import unittest
from contextlib import ExitStack
from unittest.mock import patch
from common import GameCase,store
class Captain(GameCase):
    def test_arena_modes_use_own_captain(self):
        self.p=self.player(level=50)
        store.add_card(self.p['uin'],70001,1101,20)
        store.add_card(self.p['uin'],70002,1201,20)
        store.set_formation(self.p['uin'],1,{3:70001,7:70002})
        store.set_formation_leader(self.p['uin'],1,70001)
        store.set_formation_leader(self.p['uin'],2,70002)
        store.set_formation_leader(self.p['uin'],3,70002)
        captured=[]
        def stop(left,right,**kw):
            captured.append(next(u['uid'] for u in left if u['is_leader']))
            raise RuntimeError('captured')
        with ExitStack() as stack:
            stack.enter_context(patch.object(self.g.bots_local,'pick_opponent',return_value=None))
            stack.enter_context(patch.object(self.g.bots_local,'bots',return_value=[]))
            stack.enter_context(patch.object(self.g,'_npc_encounter',return_value={'units':[],'name':'test'}))
            stack.enter_context(patch.object(self.g,'run_battle',side_effect=stop))
            for route in ('Arena_Challenge','RankArena_Challenge'):
                with self.assertRaises(RuntimeError):self.route(route)
        self.assertEqual(captured,[70002,70002])
        self.assertEqual(next(u['uid'] for u in self.g.build_player_units(self.p) if u['is_leader']),70001)
if __name__=='__main__':unittest.main()
