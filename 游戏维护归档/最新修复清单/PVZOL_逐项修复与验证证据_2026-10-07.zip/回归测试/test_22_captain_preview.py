import unittest
from unittest.mock import patch
from common import GameCase,store

class Preview(GameCase):
    def test_each_mode_preview_matches_selected_and_actual_captain(self):
        self.p=self.player(level=50)
        for uid,cid in ((70001,1101),(70002,1201),(70003,1401)):
            store.add_card(self.p['uin'],uid,cid,20)
        store.set_formation(self.p['uin'],1,{3:70001,7:70002,9:70003})
        for team,uid in ((1,70001),(2,70002),(3,70003)):store.set_formation_leader(self.p['uin'],team,uid)
        enemy={'pos':1,'card_id':10001,'hp':100,'level':1,'power':50,'is_leader':True}
        for kind,team,uid in ((0,1,70001),(self.g._ARENA_TARGET,2,70002),(self.g._RANK_ARENA_TARGET,3,70003)):
            for enemies in ([enemy],[]):
                with self.subTest(target=kind,enemies=bool(enemies)):
                    target=self.g.pb_varint_field(1,kind)+self.g.pb_varint_field(8,810000002)
                    with patch.object(self.g,'_npc_encounter',return_value={'units':enemies,'name':'test'}),patch.object(self.g,'preview_enemy_units',return_value=enemies):
                        reply=self.route('Battle_GetFightInfo',self.g.pb_bytes(1,target))
                    formation=self.g.parse_repeated_submessages(reply,1)[0]
                    fields=self.g.parse_varint_fields(formation)
                    self.assertEqual((fields[3],fields[5]),(uid,team))
                    actual=self.g.build_player_units(self.p,leader_team_id=team)
                    self.assertEqual(next(u['uid'] for u in actual if u['is_leader']),uid)

if __name__=='__main__':unittest.main()
