import time,unittest
from common import GameCase,store

class PermanentTD(GameCase):
    def use(self,iid):
        return self.route('Item_Use',self.g.pb_varint_field(1,iid))
    def test_limited_cards_never_shorten_permanent_entitlement_or_consume_stock(self):
        self.p=self.player(td_privilege=1,td_privilege_endtime=0)
        for iid in (5013,5014):
            with self.subTest(iid=iid):
                store.add_item(self.p['uin'],iid,1)
                reply=self.use(iid)
                self.assertEqual(reply,[self.g._logic_error(222)])
                saved,_=store.get_or_create_player(self.p['uin'])
                self.assertEqual((saved['td_privilege'],saved['td_privilege_endtime']),(1,0))
                self.assertEqual((self.p['td_privilege'],self.p['td_privilege_endtime']),(1,0))
                self.assertEqual(store.get_item_count(self.p['uin'],iid),1)
                self.assertTrue(self.g.td_privilege_active(self.p))
    def test_zero_end_with_no_entitlement_can_activate_and_finite_entitlement_can_stack(self):
        self.p=self.player(td_privilege=0,td_privilege_endtime=0)
        store.add_item(self.p['uin'],5013,1);self.use(5013)
        end=self.p['td_privilege_endtime'];self.assertAlmostEqual(end-int(time.time()),30*86400,delta=2)
        store.add_item(self.p['uin'],5014,1);self.use(5014)
        self.assertEqual(self.p['td_privilege_endtime'],end+7*86400)
        self.assertEqual(store.get_item_count(self.p['uin'],5014),0)

if __name__=='__main__':unittest.main()
