import sys
import unittest
from unittest.mock import patch
from common import GameCase,store,launcher
import gm
import admin_server as admin

class Uin(GameCase):
    def test_launcher_uint32_boundary(self):
        mod=launcher()
        for v in ('001','0000000000000000001','4294967295'): self.assertTrue(mod.valid_uin(v))
        for v in ('0','4294967296','9223372036854775807','１２','1&x=2','9'*500): self.assertFalse(mod.valid_uin(v))
    def test_gm_rejects_before_creating_account(self):
        with patch.object(sys,'argv',['gm.py','4294967296']):
            with self.assertRaises(SystemExit) as exc: gm.main()
        self.assertNotEqual(exc.exception.code,0)
        with store._db() as con:
            self.assertIsNone(con.execute('SELECT 1 FROM players WHERE uin=?',(4294967296,)).fetchone())
    def test_admin_uin_all_entry_bounds_and_role_id_preserved(self):
        for cap in (None,9223372036854775807):
            with self.assertRaises(admin.ValidationError): admin._integer({'uin':['4294967296']},'uin',1,cap,'UIN')
            self.assertEqual(admin._integer({'uin':['4294967295']},'uin',1,cap,'UIN'),4294967295)
        self.assertEqual(admin._integer({'role_id':['9223372036854775807']},'role_id',1,None),9223372036854775807)

if __name__=='__main__':unittest.main()
