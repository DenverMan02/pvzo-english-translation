from pathlib import Path
import importlib.util
import sys
import tempfile
import unittest
import logging
import ast

BASE=Path(__file__).resolve().parents[1]
GAME=BASE/'game'
SERVER=GAME/'PvZ-Server-PoC'
sys.path.insert(0,str(SERVER))
import player_store as store

def launcher():
    spec=importlib.util.spec_from_file_location('repair_launcher',GAME/'launcher.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def function(path,name,namespace):
    tree=ast.parse(Path(path).read_text(encoding='utf-8'))
    candidates=[n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==name]
    assert len(candidates)==1,name
    node=candidates[0]
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),namespace)
    return namespace[name]

class GameCase(unittest.TestCase):
    def setUp(self):
        self.folder=tempfile.TemporaryDirectory(dir=str(BASE/'logs'))
        self.addCleanup(self.folder.cleanup)
        self.addCleanup(store.close_thread_db)
        store.set_db_path(str(Path(self.folder.name)/'test.db'))
        store.init_db()
        import pvz_poc_server as g
        self.g=g
        logging.disable(logging.CRITICAL)
        g.main_quest_local._PLAYER_DB_PATH=store.DB_PATH
        g.guild_local._DB_PATH=store.DB_PATH
        g.guild_local.initialize(store.DB_PATH)
        self.p,_=store.get_or_create_player(810000001)
        self.p['plants']=store.get_player_plants(self.p['uin'])
    def player(self,uin=810000001,**fields):
        p,_=store.get_or_create_player(uin)
        store.save_player(uin,**fields)
        p.update(fields)
        p['plants']=store.get_player_plants(uin)
        return p
    def route(self,name,body=b'',player=None):
        return self.g.REQUEST_HANDLERS['PVZ.Cmd.Cmd_'+name+'_CS'](body,player or self.p)

if __name__=='__main__':
    unittest.main()
