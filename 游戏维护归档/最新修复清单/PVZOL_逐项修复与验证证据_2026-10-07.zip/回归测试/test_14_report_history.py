import unittest
from contextlib import ExitStack
from unittest.mock import patch
from common import GameCase
class ReportHistory(GameCase):
    def test_reopened_history_keeps_original_query_id(self):
        with ExitStack() as s:
            for name,value in [('_npc_encounter',{'units':[],'name':'test'}),('run_battle',(False,0,0,[])),('build_fight_report',b'original report'),('_auto_puppets',[]),('_auto_puppet_list',b''),('_rank_arena_board',[]),('_rank_arena_opponent_rows',[])]:s.enter_context(patch.object(self.g,name,return_value=value))
            s.enter_context(patch.object(self.g,'_capture_arena_npcs'))
            s.enter_context(patch.object(self.g.bots_local,'pick_opponent',return_value=None))
            s.enter_context(patch.object(self.g.bots_local,'bots',return_value=[]))
            for prefix,history_field in [('Arena',8),('RankArena',1)]:
                immediate=self.route(prefix+'_Challenge')[0][1]
                report_id=self.g.parse_varint_fields(self.g.parse_repeated_submessages(immediate,3)[0])[1]
                history=self.route(prefix+'_GetMyInfo')[0][1]
                saved_id=self.g.parse_varint_fields(self.g.parse_repeated_submessages(history,history_field)[-1])[1]
                self.assertEqual(saved_id,report_id)
                queried=self.route('Battle_QueryReport',self.g.pb_int64_field(1,saved_id))
                self.assertTrue(queried[0][0].endswith('Battle_QueryReport_SC'))
                self.assertEqual(self.g.parse_repeated_submessages(queried[0][1],1),[b'original report'])
if __name__=='__main__':unittest.main()
