from pathlib import Path
import subprocess
import sys
import json
import re
import time
import os

server = Path(__file__).resolve().parent / 'audit_copy' / 'pvzol本地' / 'PvZ-Server-PoC'
logs = Path(__file__).resolve().parent / ('test_logs_normalized' if '--normalized' in sys.argv else 'test_logs')
logs.mkdir(exist_ok=True)
results = []
for test in sorted((server / 'tests').glob('test_*.py')):
    started = time.monotonic()
    env = dict(os.environ)
    if '--normalized' in sys.argv:
        env.update(PYTHONPATH=str(server), PYTHONUTF8='1',
                   PVZ_NPC_TEST_DB=str(logs / 'npc_test.db'))
    try:
        process = subprocess.run([sys.executable, str(test)], cwd=server, capture_output=True,
                                 encoding='utf-8', errors='replace', timeout=150, env=env)
        output = process.stdout + '\n' + process.stderr
        code = process.returncode
    except subprocess.TimeoutExpired as error:
        output = str(error)
        code = -999
    (logs / (test.stem + '.log')).write_text(output, encoding='utf-8')
    ran = re.search(r'Ran (\d+) tests?', output)
    result = dict(file=test.name, returncode=code, seconds=round(time.monotonic()-started, 2),
                  unittest_count=int(ran.group(1)) if ran else None)
    results.append(result)
    (logs / 'results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
    print(('PASS' if code == 0 else 'FAIL') + ' ' + test.name, flush=True)
print(json.dumps(dict(files=len(results), passed=sum(x['returncode'] == 0 for x in results),
                     failed=[x for x in results if x['returncode'] != 0]), ensure_ascii=False), flush=True)
