import time
def uvarint(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 127
        n >>= 7
        if n:
            out.append(b | 128)
        else:
            out.append(b)
            return bytes(out)

def pb_tag(field: int, wire: int) -> bytes:
    return uvarint(field << 3 | wire)

def pb_string(field: int, s: str) -> bytes:
    data = s.encode('utf-8')
    return pb_tag(field, 2) + uvarint(len(data)) + data

def pb_varint_field(field: int, value: int) -> bytes:
    return pb_tag(field, 0) + uvarint(value)

def make_init_sc(player):
    """Cmd_Init_SC — the player snapshot, loaded from the persistent store.
    All fields optional; field numbers per Cmd_Init_SC.as."""
    now = int(time.time())
    d = b''
    d += pb_string(1, player['name'])
    d += pb_varint_field(2, player['exp'])
    d += pb_varint_field(3, player['level'])
    d += pb_varint_field(4, player['sun'])
    d += pb_varint_field(5, player['coin'])
    d += pb_varint_field(8, now)
    d += pb_varint_field(9, player['role_id'])
    d += pb_varint_field(10, current_energy(player))
    d += pb_varint_field(11, player['friend_point'])
    d += pb_varint_field(13, player['face_id'])
    d += pb_string(23, player_face_url(player))
    d += pb_varint_field(15, player['ticket'])
    d += pb_varint_field(16, player['fame'])
    d += pb_varint_field(17, player['buy_energy_num'])
    d += pb_bool(18, False)
    d += pb_varint_field(20, 100)
    d += pb_varint_field(21, 100)
    d += pb_varint_field(22, player['present_ticket'])
    d += pb_varint_field(24, player['zone_id'])
    d += pb_bool(25, False)
    d += pb_varint_field(26, 1)
    d += pb_bool(27, False)
    d += pb_varint_field(28, player['reg_time'])
    d += pb_varint_field(29, player['server_open_time'])
    d += pb_varint_field(30, player['reg_time'])
    d += pb_varint_field(32, player['foster_ticket'])
    d += pb_bool(33, True)
    d += pb_bool(34, False)
    d += pb_bool(35, False)
    d += pb_varint_field(36, player['lucky'])
    d += pb_varint_field(37, player['contrib_val'])
    d += pb_varint_field(38, player['light'])
    d += pb_varint_field(39, player['last_pay_time'])
    d += pb_varint_field(40, puppet_skill_val(player))
    d += pb_varint_field(41, puppet_energy(player))
    d += pb_varint_field(44, player['prestige'])
    td_stage = 0 if player.get('tutorial_active') else player['td_stage']
    td_level = 1 if player.get('tutorial_active') else player['td_level']
    td_sub = 1 if player.get('tutorial_active') else player['td_sub']
    td = pb_varint_field(1, td_stage) + pb_varint_field(2, td_level) + pb_varint_field(3, td_sub)
    d += pb_tag(7, 2) + uvarint(len(td)) + td
    av = pb_varint_field(1, player['avatar_plant_id']) + pb_varint_field(2, 0) + pb_varint_field(3, int(player.get('avatar_skin_id') or 0)) + pb_varint_field(4, 0)
    d += pb_tag(12, 2) + uvarint(len(av)) + av
    for pid in player.get('plants', []):
        pl = pb_varint_field(1, pid) + pb_varint_field(2, 0)
        d += pb_tag(14, 2) + uvarint(len(pl)) + pl
    d += make_server_config_entries(player)
    return d
make_init_sc({'name': 'Player101', 'exp': 0, 'level': 50, 'sun': 10, 'coin': -1})
