import ast
import contextlib
import io
import json
import logging
from pathlib import Path
import struct
import subprocess
import sys
import zlib
sys.stdout.reconfigure(encoding='utf-8')

BASE = Path(__file__).resolve().parent
GAME = BASE / 'game'
sys.path[:0] = [str(GAME/'PvZ-Server-PoC'), str(GAME)]
import launcher
import player_store as store
import gm

store.init_db()
uin = 555000101
player, _ = store.get_or_create_player(uin)
store.save_player(uin, level=50, ticket=0, present_ticket=0, diamond_flag=0)

out = io.StringIO()
sys.argv = ['gm.py',str(uin),'diamond','1','7','0','0']
with contextlib.redirect_stdout(out):
    result = gm.main()
after, _ = store.get_or_create_player(uin)
print('DIAMOND',json.dumps({'gm_return': result, 'process_success_if_main': True,'output':out.getvalue().strip(),'diamond_flag_after':after['diamond_flag']},ensure_ascii=False))

import pvz_poc_server as srv
srv.log.setLevel(logging.WARNING)
srv.load_card_level_curve()
srv.load_battle_cards()
card_id = next(cid for cid,d in srv._BATTLE_CARDS.items() if d.get('maxLv',0)>=20)
store.add_card(uin,55501,card_id)
sys.argv = ['gm.py',str(uin),'cardlevel','20']
with contextlib.redirect_stdout(io.StringIO()):
    gm.main()
before = store.get_cards(uin)
sys.argv = ['gm.py',str(uin),'cardlevel','9999']
out = io.StringIO()
with contextlib.redirect_stdout(out):
    gm.main()
print('CARDLEVEL',json.dumps({'curve_min':min(x[0] for x in srv._CARD_LEVEL_CURVE),'curve_max':max(x[0] for x in srv._CARD_LEVEL_CURVE),'before':before,'after':store.get_cards(uin),'output':out.getvalue().strip()},ensure_ascii=False))

uin_text='4294967297'
wire_uin=int(uin_text)&0xffffffff
body=srv.xor7(srv.pb_string(1,'PVZ.Cmd.Cmd_CheckOldUser_CS'))
packet=bytes([202])+struct.pack('>II',23+len(body),len(body))+bytes([1,2,1])+struct.pack('>II',wire_uin,3)+b'xx\0'+body
print('ACCOUNT',json.dumps({'entered':uin_text,'launcher_accepts':launcher.valid_uin(uin_text),'parsed_wire_uin':srv.describe_c2s(packet)['uin'],'editor_will_use':int(uin_text)},ensure_ascii=False))

class Variable:
    def __init__(self, value): self.value=value
    def get(self): return self.value
class Status:
    def configure(self, **kw): self.result=kw
class GmStub:
    def __init__(self): self.calls=[]
    def _run_gm(self,args): self.calls.append(args); return True,'ok'

tree=ast.parse((GAME/'launcher.py').read_text(encoding='utf-8'))
func=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='apply_main')
globals_={'self':GmStub(),'save_profile':lambda:True,'uin':'555000101','FIELDS':[('金币','coin')],'ed_vars':{'coin':Variable('abc')},'VIP_OPTS':['关闭','VIP1','VIP2','VIP3'],'vip_var':Variable('关闭'),'TD_OPTS':['关闭','开启'],'td_var':Variable('关闭'),'status':Status(),'ACCENT':'green','STOP':'red'}
exec(compile(ast.Module(body=[func],type_ignores=[]),str(GAME/'launcher.py'),'exec'),globals_)
globals_['apply_main']()
print('INVALID_FIELD',json.dumps({'input_coin':'abc','calls':globals_['self'].calls,'status':globals_['status'].result},ensure_ascii=False))

sys.argv=['gm.py',str(uin),'coin','-1']
with contextlib.redirect_stdout(io.StringIO()):
    gm.main()
after,_=store.get_or_create_player(uin)
server_tree=ast.parse((GAME/'PvZ-Server-PoC/pvz_poc_server.py').read_text(encoding='utf-8'))
names={'uvarint','pb_tag','pb_string','pb_varint_field','make_init_sc'}
selected=[n for n in server_tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
code='import time\n'+ast.unparse(ast.Module(body=selected,type_ignores=[]))+'\nmake_init_sc('+repr({k:after[k] for k in ('name','exp','level','sun','coin')})+')\n'
child=BASE/'negative_coin_init.py'
child.write_text(code,encoding='utf-8')
try:
    p=subprocess.run([sys.executable,'-B',str(child)],capture_output=True,text=True,timeout=0.5)
    frozen=False
except subprocess.TimeoutExpired:
    frozen=True
print('NEGATIVE_COIN',json.dumps({'stored_coin':after['coin'],'make_init_sc_timeout_0_5_seconds':frozen},ensure_ascii=False))

# Opening an editor captures each currency once; the independent diamond action
# changes the database, but apply_main subsequently submits all captured values.
store.save_player(uin,coin=100,ticket=100,present_ticket=0,diamond_flag=0)
ticket_captured_when_opening=100
sys.argv=['gm.py',str(uin),'diamond','1','1','0','0']
with contextlib.redirect_stdout(io.StringIO()):
    gm.main()
after_diamond,_=store.get_or_create_player(uin)
class RealGm:
    def _run_gm(self,args):
        sys.argv=['gm.py',*args]
        with contextlib.redirect_stdout(io.StringIO()):
            gm.main()
        return True,'ok'
globals_.update(self=RealGm(), FIELDS=[('金钻','ticket')],ed_vars={'ticket':Variable(str(ticket_captured_when_opening))})
globals_['apply_main']()
after_apply,_=store.get_or_create_player(uin)
print('STALE_EDITOR',json.dumps({'ticket_on_open':ticket_captured_when_opening,'ticket_after_diamond':after_diamond['ticket'],'ticket_after_apply':after_apply['ticket']},ensure_ascii=False))

class GuardProbe:
    running=True
    _run_gm=launcher.Launcher._run_gm
guard=GuardProbe()
print('ONLINE_GUARD',json.dumps({'while_running':guard._run_gm([str(uin),'coin','100'])},ensure_ascii=False))
guard.running=False
launcher.port_open=lambda port:True
print('ONLINE_GUARD',json.dumps({'while_game_port_open':guard._run_gm([str(uin),'coin','100'])},ensure_ascii=False))

for path in [Path(r'D:\pvzol本地最新最新ol\一键启动游戏.exe'),Path(r'D:\pvzol本地最新最新ol\pvzol本地\运行环境\PvZRuntime.exe')]:
    data=path.read_bytes()
    idx=data.rfind(b'MEI\x0c\x0b\x0a\x0b\x0e')
    magic,size,tocpos,toclen,version,pylib=struct.unpack('!8sIIII64s',data[idx:idx+88])
    start=idx+88-size
    toc=data[start+tocpos:start+tocpos+toclen]
    pos=0; entries=[]
    while pos<len(toc):
        length,offset,packed,unpacked,comp,type_=struct.unpack('!IIIIBB',toc[pos:pos+18])
        name=toc[pos+18:pos+length].rstrip(b'\0').decode()
        entries.append(name)
        if name=='portable_boot':
            boot=data[start+offset:start+offset+packed]
            boot=zlib.decompress(boot) if comp else boot
            (BASE/(path.stem+'_portable_boot.marshal')).write_bytes(boot)
            print('BOOT',json.dumps({'exe':str(path),'python_version':version,'bootstrap_bytes':len(boot),'dynamic_launcher_source':b'launcher.py' in boot,'dynamic_runpy':b'run_path' in boot,'sets_frozen_false':b'frozen' in boot,'sets_runtime':b'_pvz_runtime' in boot},ensure_ascii=False))
        pos+=length
    print('BOOT_ENTRIES',path.name,entries[:30])
