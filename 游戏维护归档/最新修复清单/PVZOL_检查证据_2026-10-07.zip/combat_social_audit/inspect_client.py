import sys, importlib.util
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
source=Path(__file__).parents[1] / 'audit_copy/pvzol本地/PvZ-Server-PoC/client_tools/abcdis.py'
spec=importlib.util.spec_from_file_location('abcdis',source)
a=importlib.util.module_from_spec(spec)
parser_source=source.read_text(encoding='utf-8').replace('r2.u30()\n                    pos = r2.pos\n                    args.append(f"-> {start + s24 if False else pos + s24}")',
                                                       'pos += 3\n                    args.append(f"-> {pos + s24}")')
exec(compile(parser_source,str(source),'exec'),a.__dict__)
def traits(self,r):
    out=[]
    for _ in range(r.u30()):
        name=r.u30();k=r.u8();tag=k&15
        entry={'name':self.mn(name),'kind':tag}
        if tag in (0,6):
            entry['slot'],entry['type']=r.u30(),r.u30()
            v=r.u30()
            if v:entry['vkind']=r.u8()
        elif tag in (1,2,3):entry['disp'],entry['method']=r.u30(),r.u30()
        elif tag==4:entry['slot'],entry['class']=r.u30(),r.u30()
        elif tag==5:entry['slot'],entry['method']=r.u30(),r.u30()
        else:raise ValueError('trait kind '+str(tag))
        if k&64:
            for _ in range(r.u30()):r.u30()
        out.append(entry)
    return out
a.Abc._traits=traits
for blob in a.abc_blobs(sys.argv[1]):
    abc=a.Abc(blob)
    r=a.Reader(blob,abc.pool_pos)
    n=r.u30();abc.methods=[]
    for i in range(n):
        pc,ret=r.u30(),r.u30()
        params=[r.u30() for _ in range(pc)];name=r.u30();flags=r.u8()
        if flags&8:
            for _ in range(r.u30()):r.u30();r.u8()
        if flags&128:
            for _ in range(pc):r.u30()
        abc.methods.append({'name':abc.strings[name],'params':pc})
    for _ in range(r.u30()):
        r.u30();items=r.u30()
        for _ in range(items*2):r.u30()
    abc.tail_pos=r.pos
    abc.load(tries=12)
    print('PARSED_CLASSES',len(abc.classes),'METHOD_BODIES',len(abc.bodies))
    for c in abc.classes:
        if sys.argv[2].lower() in c['name'].lower():
            print('CLASS',c['name'])
            for name,idx in abc.trait_methods(c,sys.argv[3] if len(sys.argv)>3 else ''):
                print('METHOD',name,idx)
                body=abc.body_of_method.get(idx)
                if body:print('\n'.join(abc.disassemble(body['code'])))
