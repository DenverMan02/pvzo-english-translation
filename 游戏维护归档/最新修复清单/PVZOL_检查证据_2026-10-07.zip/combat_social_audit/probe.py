import sys, time, json, copy
sys.stdout.reconfigure(encoding='utf-8')
from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).parent / 'server'))
import player_store as store
store.set_db_path(str(Path(__file__).parent / ('probe_%d.db' % time.time_ns())))
store.init_db()
import pvz_poc_server as g
import guild_local as guild

def unit(pos, **kw):
    u = dict(pos=pos,card_id=101,hp=10000,atk=100,def_=0,ability=0,skill1=51,skill2=0,is_leader=False,level=1,power=100)
    u.update(kw)
    return u

def call(name, data, p):
    return g.REQUEST_HANDLERS['PVZ.Cmd.'+name+'_CS'](data, p)

g.load_battle_cards();g.load_skill_info()
p,_=store.get_or_create_player(883101)
p.update(level=100,coin=10**8,energy=0,energy_time=int(time.time()))
store.save_player(p['uin'],level=100,coin=p['coin'],energy=0,energy_time=p['energy_time'])
g.ensure_player_cards(p)
store.add_card(p['uin'],7000001,1101,60);store.add_card(p['uin'],7000002,1205,60)
store.set_formation(p['uin'],1,{3:7000001,7:7000002})
store.set_formation_leader(p['uin'],1,7000001)
form=g.pb_bytes(1,g.pb_bytes(1,g.pb_varint_field(1,3)+g.pb_int64_field(2,7000001))+
                g.pb_bytes(1,g.pb_varint_field(1,7)+g.pb_int64_field(2,7000002))+g.pb_int64_field(3,7000002))
out={}
reply=call('Cmd_Arena_SetFormation',form,p)
visible=g.parse_varint_fields(g.parse_repeated_submessages(reply[0][1],1)[0])[3]
out['arena_captain']={'selected_and_getformation_leader':visible,
                     'actual_battle_leader':next(u['uid'] for u in g.build_player_units(p) if u['is_leader']),
                     'leader_team1':store.get_formation_leader(p['uin'],1),'leader_team2':store.get_formation_leader(p['uin'],2)}

opponent={'uin':900001,'name':'probe','power':100,'level':1}
with ExitStack() as stack:
    stack.enter_context(patch.object(g.bots_local,'pick_opponent',return_value=opponent))
    stack.enter_context(patch.object(g.bots_local,'bots',return_value=[opponent]))
    stack.enter_context(patch.object(g,'_refresh_arena_npcs'))
    stack.enter_context(patch.object(g,'_npc_encounter',return_value={'units':[unit(4,hp=100,atk=1)],'name':'probe','level':1}))
    stack.enter_context(patch.object(g.bots_local,'apply_match_result'))
    r=call('Cmd_Arena_Challenge',b'',p)
    immediate_id=g.parse_varint_fields(g.parse_repeated_submessages(r[0][1],3)[0])[1]
    left_side=g.parse_repeated_submessages(g._BATTLE_REPORTS[immediate_id],2)[0]
    actual_captain=[g.parse_varint_fields(c) for c in g.parse_repeated_submessages(left_side,2) if g.parse_varint_fields(c).get(9)]
    out['arena_captain']['battle_report_leader_card_id']=actual_captain[0][2]
    out['arena_captain']['requested_leader_card_id']=1205
    info=call('Cmd_Arena_GetMyInfo',b'',p)
    reopened_id=g.parse_varint_fields(g.parse_repeated_submessages(info[0][1],8)[0])[1]
    immediate_query=call('Cmd_Battle_QueryReport',g.pb_int64_field(1,immediate_id),p)[0][0]
    reopened_query=call('Cmd_Battle_QueryReport',g.pb_int64_field(1,reopened_id),p)[0][0]
    out['arena_replay']={'immediate_report_id':immediate_id,'reopened_report_id':reopened_id,
                         'immediate_query_result':immediate_query,'reopened_query_result':reopened_query,
                         'saved_record':g._arena_state(p,'arena_data')['records'][-1]}

data=g._arena_state(p,'rank_arena_data');data['challenges']=10;g._save_json_state(p,'rank_arena_data',data)
r=call('Cmd_RankArena_Challenge',g.pb_int64_field(1,900001),p)
out['rank_limit']={'command':r[0][0],'reply_bytes':len(r[0][1]),'recorder_count':len(g.parse_repeated_submessages(r[0][1],3))}

left=[unit(3,skill1=5901,initial_hp=6000,shield=400,ability=50),unit(9,initial_hp=8000)]
right=[unit(4,shield=700),unit(10)]
state={};rounds=g.simulate_battle(left,right,True,result_state=state,max_rounds=1)
out['skill_5901']={'skill_description':g._SKILL_DESCS[5901],
                   'self_event':[d for aa,bb in rounds for a in aa for d in a['damages'] if d['target']==3 and d['dmg']>0],
                   'server_final_hp':state['hp'][3],'server_final_shield':state['shield'][3],
                   'cards_using_590x':[(cid,c['name'],c['skill1'],c['skill2']) for cid,c in g._BATTLE_CARDS.items() if 5901<=c['skill1']<=5905 or 5901<=c['skill2']<=5905]}
native_hp={u['pos']:u.get('initial_hp',u['hp']) for u in left+right}
native_max={u['pos']:u['hp'] for u in left+right}
native_sh={u['pos']:u.get('shield',0) for u in left+right}
def signed(n):return n-(1<<64) if n >= 1<<63 else n
for rr in g.parse_repeated_submessages(g.encode_fight_replay(rounds),4):
    dd=[d for aa in g.parse_repeated_submessages(rr,2) for d in g.parse_repeated_submessages(aa,2)]
    dd+=g.parse_repeated_submessages(rr,3)
    for body in dd:
        e=g.parse_varint_fields(body);t=e[1]
        cap=signed(e.get(11,0));delta=signed(e.get(2,0))
        native_max[t]+=cap
        native_hp[t]=min(native_max[t],native_hp[t]+max(0,cap))
        native_hp[t]=min(native_max[t],max(0,native_hp[t]+delta))
        native_sh[t]=0 if delta<0 else max(0,native_sh[t]+signed(e.get(6,0)))
out['skill_5901']['native_replay_final_shield']=native_sh[3]
out['leader10605']={'configured_description':g._SKILL_DESCS[10605],'engine_effect':g._leader_effect(10605)}

g.store.save_player(p['uin'],energy=0,energy_time=int(time.time()))
p.update(energy=0,energy_time=int(time.time()))
target=g.pb_bytes(1,g.pb_varint_field(1,1)+g.pb_varint_field(2,1)+g.pb_varint_field(3,1)+g.pb_varint_field(4,1))
before=p['coin'];r=call('Cmd_Battle_Fight',target,p)
out['zero_energy_adventure']={'requested_cost':g.fuben_energy_cost(1,1,1),'energy':p['energy'],'coin_delta':p['coin']-before,
                              'fight_reply':r[0][0],'passed':store.get_fuben_passed(p['uin'],1,1)}

# Pending applicants are both legal while one seat remains. Approval must recheck the limit.
with guild._db() as con:
    cur=con.execute('INSERT INTO local_guilds(name,created_at) VALUES(?,?)',('probe guild',int(time.time())))
    gid=cur.lastrowid
    limit=guild._member_limit(guild._guild(con,gid))
    guild._add_member(con,guild._guild(con,gid),p,position=1)
for idx in range(limit-2):
    member,_=store.get_or_create_player(883200+idx)
    with guild._db() as con:guild._add_member(con,guild._guild(con,gid),member)
applicants=[]
for uin in (883901,883902):
    a,_=store.get_or_create_player(uin);applicants.append(a)
    call('Cmd_GuildJoinReq',g.pb_varint_field(1,gid),a)
for a in applicants:
    call('Cmd_GuildAckJoin',g.pb_int64_field(1,a['role_id'])+g.pb_bool(2,True),p)
with guild._db() as con:
    count=con.execute('SELECT COUNT(*) FROM local_guild_members WHERE guild_id=?',(gid,)).fetchone()[0]
out['guild_capacity']={'configured_max_member':limit,'members_after_two_legal_pending_applications_approved':count}

print('EVIDENCE_JSON_START')
print(json.dumps(out,ensure_ascii=False,indent=2))
print('EVIDENCE_JSON_END')
Path(__file__).with_name('evidence.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
store.close_thread_db()
