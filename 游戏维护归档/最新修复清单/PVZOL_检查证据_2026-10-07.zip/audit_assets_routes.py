from pathlib import Path
import sys
import json
import collections
import threading
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
import re

base = Path(__file__).resolve().parent / 'audit_copy' / 'pvzol本地'
server = base / 'PvZ-Server-PoC'
sys.path.insert(0, str(server))
import serve_client as sc
import pvz_poc_server as g

original = Path(r'D:\pvzol本地最新最新ol\pvzol本地')
counts = collections.Counter()
for line in (original / 'PvZ-Server-PoC' / 'client_asset_errors.log').read_text(encoding='utf-8', errors='replace').splitlines():
    match = re.match(r'07/Oct/2026 \S+ (404|IMAGE_FALLBACK) (.+)', line)
    if match:
        counts[(match[1], match[2])] += 1
http = sc.Server(('127.0.0.1', 0), sc.Handler)
thread = threading.Thread(target=http.serve_forever, daemon=True)
thread.start()
responses = []
try:
    for (old_status, path), count in counts.items():
        url = 'http://127.0.0.1:%s%s' % (http.server_address[1], path)
        try:
            with urllib.request.urlopen(url, timeout=3) as response:
                body = response.read()
                status = response.status
                blank = body == sc.PLACEHOLDER_PNG
        except urllib.error.HTTPError as error:
            status, blank = error.code, False
        responses.append(dict(path=path, log_status=old_status, hits=count, now_status=status, placeholder=blank,
                              exists=(original / 'webroot' / path.lstrip('/')).is_file()))
finally:
    http.shutdown()
    http.server_close()
commands = {p.stem for p in (base / 'Assets' / 'src' / 'PVZ' / 'Cmd').glob('Cmd_*_CS.as')}
registered = {name.rsplit('.', 1)[-1] for name in g.REQUEST_HANDLERS}
missing = sorted(commands - registered)
data = dict(assets=responses, commands=len(commands), registered=len(registered),
            covered_client_commands=len(commands & registered), missing_commands=missing)
target = Path(__file__).resolve().parent / 'assets_routes.json'
target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(dict(assets_today=len(responses), still404=[x for x in responses if x['now_status']==404],
                     still_blank=sum(x['placeholder'] for x in responses), client_commands=len(commands),
                     registered=len(registered), missing=len(missing)), ensure_ascii=False), flush=True)
