from pathlib import Path
import shutil

base = Path(__file__).resolve().parent / 'audit_copy' / 'pvzol本地'
server = base / 'PvZ-Server-PoC'
source = Path(r'D:\pvzol本地最新最新ol\pvzol本地\PvZ-Server-PoC')
shutil.copytree(source / 'patch_exports', server / 'patch_exports', dirs_exist_ok=True)
for name in ('test_skill_effects.py', 'test_energy_shield_cleanse.py'):
    path = server / 'tests' / name
    text = path.read_text(encoding='utf-8')
    for line in text.splitlines():
        if line.startswith('CLIENTDB = '):
            text = text.replace(line, 'CLIENTDB = Path(__file__).resolve().parents[2] / "webroot" / "clientDB.txt"')
    path.write_text(text, encoding='utf-8')
print('Only copied tests: portable clientDB paths and missing test fixture files restored.')
