import sys,pathlib,logging,json
sys.path.insert(0,str(pathlib.Path(__file__).parent/'PvZ-Server-PoC'))
import player_store as s
s.set_db_path(str(pathlib.Path(__file__).parent/'probe_consumables.db'));s.init_db()
import pvz_poc_server as g
logging.disable(logging.CRITICAL)
p,_=s.get_or_create_player(809003);p.update(level=50,energy=10,vip_level=0);s.save_player(p['uin'],level=50,energy=10,vip_level=0)
fields=('energy','vip_level','td_privilege_endtime','nutrition_gold')
for iid in (2015,5001,5013,60000,96001):
 s.add_item(p['uin'],iid,1)
 before={x:p.get(x) for x in fields};res=g.REQUEST_HANDLERS['PVZ.Cmd.Cmd_Item_Use_CS'](g.pb_varint_field(1,iid)+g.pb_varint_field(2,1),p);after={x:p.get(x) for x in fields}
 print('item-use',iid,'held_before',1,'held_after',s.get_item_count(p['uin'],iid),'before',before,'after',after,'puppets',list(s.get_puppets(p['uin'])),'reply',[(n,g.parse_varint_fields(b)) for n,b in res])
print('wt rows',[(i,r.get('power')) for i,r in g.load_wt().items() if r.get('power')][:10])
print('mall data types',{r[0]:r[1] for r in []})
p2,_=s.get_or_create_player(809005);s.save_player(p2['uin'],level=20);a=s.get_or_create_player(p2['uin'])[0];b=s.get_or_create_player(p2['uin'])[0]
req=g.pb_varint_field(1,4)+g.pb_varint_field(2,20)
for label,who in [('A',a),('B',b)]:
 res=g.REQUEST_HANDLERS['PVZ.Cmd.Cmd_Welfare_Take_CS'](req,who)
 print('welfare',label,'items',s.get_items(p2['uin']),'coin',s.get_or_create_player(p2['uin'])[0]['coin'],'response',[n for n,_ in res])
s.close_thread_db()

