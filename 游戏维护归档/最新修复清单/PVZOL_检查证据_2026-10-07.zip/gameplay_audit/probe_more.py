import sys, pathlib, logging,json
sys.path.insert(0,str(pathlib.Path(__file__).parent/'PvZ-Server-PoC'))
import player_store as s
s.set_db_path(str(pathlib.Path(__file__).parent/'probe_more.db'));s.init_db()
import pvz_poc_server as g
logging.disable(logging.CRITICAL)
p,_=s.get_or_create_player(808002);p.update(level=50,coin=100000);s.save_player(p['uin'],level=50,coin=100000)
p['plants']=s.get_player_plants(p['uin']);g.ensure_player_cards(p)
print('startercards',s.get_cards(p['uin']))
c=next(c for c in s.get_cards(p['uin']) if g._BATTLE_CARDS[c[1]].get('recycleItemNum',0)>0);uid,cid=c[:2];iid=g._BATTLE_CARDS[cid]['recycleItemId']
for i in range(3):
 g.REQUEST_HANDLERS['PVZ.Cmd.Cmd_Card_Recycle_CS'](g.pb_int64_field(1,uid),p)
 print('recycled',i,'heldFragments',s.get_item_count(p['uin'],iid),'cardexists',s.get_cards(p['uin']))
 g.REQUEST_HANDLERS['PVZ.Cmd.Cmd_Card_GetPackage_CS'](b'',p)
 print('package',i,'regenerated',next((c for c in s.get_cards(p['uin']) if c[0]==uid),None))
print('fragment item',iid,'amount',g._BATTLE_CARDS[cid]['recycleItemNum'])
statbefore=g.effective_card_stats(p,cid,1,uid=uid);g.handle_lab_getlabinfo(b'',p)
for lid in (5,6,7,8):
 g.handle_lab_produce(g.pb_varint_field(1,lid),p)
 g.handle_lab_upgrade(g.pb_varint_field(1,lid),p)
 print('labpurchase',lid,g._lab_load_state(p)[lid],g.load_lab()[lid]['levels'][g._lab_load_state(p)[lid][0]]['stat'])
statafter=g.effective_card_stats(p,cid,1,uid=uid)
print('critstats_before_after',{x:statbefore.get(x) for x in ('hit','dodge','critical','tough')},{x:statafter.get(x) for x in ('hit','dodge','critical','tough')},'lab_bonus',g.lab_stat_bonus(p))
rows=g._read_clientdb_table('ItemInfo.txt');maps=[dict(zip(rows[0],r)) for r in rows[1:]]
for row in maps:
 if row.get('isUse')=='1' and row.get('type')=='2' and row.get('id') not in map(str,g.load_chest_index()):
  print('nonchest-use',json.dumps({k:row.get(k) for k in ('id','name','subType','desc','useEffect')},ensure_ascii=True))
s.close_thread_db()

