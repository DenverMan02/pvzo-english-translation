import sys,pathlib,logging,time
sys.path.insert(0,str(pathlib.Path(__file__).parent/'PvZ-Server-PoC'))
import player_store as s
path=str(pathlib.Path(__file__).parent/'probe_lock.db');s.set_db_path(path);s.init_db()
import pvz_poc_server as g
logging.disable(logging.CRITICAL)
g.main_quest_local._PLAYER_DB_PATH=path
p,_=s.get_or_create_player(809001);s.save_player(p['uin'],level=100);p['level']=100
uid=10001101;s.add_card(p['uin'],uid,1101,100,0);board=g.load_card_puzzle()[1]
for i in range(board['width']*board['height']):s.add_card_filled_index(p['uin'],uid,i)
g.main_quest_local.get_list(p['uin'],g._main_quest_rows())
t=time.monotonic()
try:
 result=g.REQUEST_HANDLERS['PVZ.Cmd.Cmd_Card_FinishFill_CS'](g.pb_int64_field(1,uid),p)
 print('finish result',result)
except Exception as e:print('finish exception',type(e).__name__,str(e),'seconds=',round(time.monotonic()-t,3))
print('quality_after',s.get_card_fill_quality(p['uin'],uid),'indices_after',s.get_card_filled_indices(p['uin'],uid))
p2,_=s.get_or_create_player(809002);s.save_player(p2['uin'],ticket=100000,present_ticket=0);a=s.get_or_create_player(p2['uin'])[0];b=s.get_or_create_player(p2['uin'])[0]
for label,who in [('A',a),('B',b)]:
 before=s.get_or_create_player(p2['uin'])[0]['ticket'];row_before=s.get_equipment_state(p2['uin']); tpl=g._equip_row('EquipmentBead.txt',id=row_before['buy_count']+1)
 result=g.REQUEST_HANDLERS['PVZ.Cmd.Cmd_Equip_BuyBead_CS'](b'',who)
 after=s.get_or_create_player(p2['uin'])[0]['ticket'];print('bead',label,'price',tpl['cost'],'count',tpl['count'],'wallet_before',before,'wallet_after',after,'reply',[x[0] for x in result])
s.close_thread_db()
