import sys, pathlib, logging, json
src = pathlib.Path(__file__).parent / 'PvZ-Server-PoC'
sys.path.insert(0,str(src))
import player_store as s
s.set_db_path(str(pathlib.Path(__file__).parent/'probe.db')); s.init_db()
import pvz_poc_server as g
logging.disable(logging.CRITICAL)
p,_=s.get_or_create_player(808001)
p['level']=50;s.save_player(p['uin'],level=50)
s.add_card(p['uin'],10001101,1101,1);s.add_item(p['uin'],2002,1)
e=g.pb_varint_field(1,2002)+g.pb_varint_field(2,1)
req=g.pb_int64_field(1,10001101)+g.pb_bytes(2,e)+g.pb_bytes(2,e)
before=s.get_cards(p['uin']); reply=g.REQUEST_HANDLERS['PVZ.Cmd.Cmd_Card_FasterLevelUp_CS'](req,p);after=s.get_cards(p['uin'])
print('duplicate-bean',before,after,'held=',s.get_item_count(p['uin'],2002))
print('lab', [(i,b['type'],b['levels'][b['minLevel']], b['levels'].get(b['minLevel']+1)) for i,b in g.load_lab().items()][:10])
rows=g._read_clientdb_table('ItemInfo.txt'); maps=[dict(zip(rows[0],r)) for r in rows[1:]]
for row in maps:
 if row.get('id') in ('2001','2002','2003','2007','2008','2024','2029','2047') or (row.get('type')=='2' and row.get('canUse')=='1' and int(row['id'])<4000):
  print('usable', {k:row.get(k) for k in ('id','name','type','subType','canUse','isMulUse','describe','effect','roleLvNeed','useLvLimit','cardItemId')})
print('itemcolumns',rows[0])
s.close_thread_db()
