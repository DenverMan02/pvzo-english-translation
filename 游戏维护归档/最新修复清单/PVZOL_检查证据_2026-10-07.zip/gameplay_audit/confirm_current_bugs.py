"""Read-only source audit; each run uses a fresh disposable SQLite save."""
import json
import logging
from pathlib import Path
import sqlite3
import sys
import tempfile
import time

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / "PvZ-Server-PoC"))
import player_store as store

results = []
with tempfile.TemporaryDirectory(prefix="confirmation_", dir=str(BASE)) as tmp:
    db = str(Path(tmp) / "players.db")
    store.set_db_path(db)
    store.init_db()
    import pvz_poc_server as g
    logging.disable(logging.CRITICAL)
    g.main_quest_local._PLAYER_DB_PATH = db

    def player(uin, **values):
        p, _ = store.get_or_create_player(uin)
        store.save_player(uin, **values)
        p.update(values)
        p["plants"] = store.get_player_plants(uin)
        return p

    def call(name, request, p):
        return g.REQUEST_HANDLERS["PVZ.Cmd.Cmd_" + name + "_CS"](request, p)

    p = player(810001, level=50)
    uid = 10001101
    store.add_card(p["uin"], uid, 1101, 1)
    store.add_item(p["uin"], 2002, 1)
    entry = g.pb_varint_field(1, 2002) + g.pb_varint_field(2, 1)
    call("Card_FasterLevelUp", g.pb_int64_field(1, uid)
         + g.pb_bytes(2, entry) + g.pb_bytes(2, entry), p)
    card = store.get_cards(p["uin"])[0]
    assert card[3] == 20000 and store.get_item_count(p["uin"], 2002) == 0
    results.append({"id": "economy-03", "exp_for_one_bean": card[3], "remaining_beans": 0})

    p = player(810002, level=50)
    g.ensure_player_cards(p)
    for cycle in range(3):
        call("Card_Recycle", g.pb_int64_field(1, uid), p)
        assert store.get_item_count(p["uin"], 51100) == (cycle + 1) * 20
        call("Card_GetPackage", b"", p)
        assert any(c[0] == uid for c in store.get_cards(p["uin"]))
    results.append({"id": "economy-02", "cycles": 3, "fragments": 60, "free_card_still_present": True})

    p = player(810003, level=50, coin=100000)
    store.add_card(p["uin"], uid, 1101, 1)
    before = g.effective_card_stats(p, 1101, 1, uid=uid)
    call("Lab_GetLabInfo", b"", p)
    for lab in (5, 6, 7, 8):
        call("Lab_ProduceLab", g.pb_varint_field(1, lab), p)
        call("Lab_UpgradeLab", g.pb_varint_field(1, lab), p)
        assert g._lab_load_state(p)[lab] == (2, 2)
    after = g.effective_card_stats(p, 1101, 1, uid=uid)
    keys = ("hit", "dodge", "critical", "tough")
    assert all(before.get(k) == after.get(k) for k in keys)
    results.append({"id": "economy-05", "lab_levels": [2, 2, 2, 2],
                    "before": {k: before.get(k) for k in keys},
                    "after": {k: after.get(k) for k in keys}})

    p = player(810004, level=50, energy=10, vip_level=0)
    unchanged = []
    for item in (2015, 5001, 5013, 60000, 96001):
        store.add_item(p["uin"], item, 1)
        reply = call("Item_Use", g.pb_varint_field(1, item)
                     + g.pb_varint_field(2, 1), p)
        assert store.get_item_count(p["uin"], item) == 1
        assert p["energy"] == 10 and p["vip_level"] == 0
        assert p["td_privilege_endtime"] == 0 and p["nutrition_gold"] == 0
        assert not store.get_puppets(p["uin"])
        assert len(reply) == 1 and reply[0][0].endswith("Item_Use_SC")
        unchanged.append(item)
    results.append({"id": "economy-06", "success_ack_without_consumption_or_effect": unchanged})

    p = player(810005, ticket=100000, present_ticket=0)
    a = store.get_or_create_player(p["uin"])[0]
    b = store.get_or_create_player(p["uin"])[0]
    call("Equip_BuyBead", b"", a)
    first_balance = store.get_or_create_player(p["uin"])[0]["ticket"]
    call("Equip_BuyBead", b"", b)
    second_balance = store.get_or_create_player(p["uin"])[0]["ticket"]
    beads = store.get_item_count(p["uin"], 2046)
    assert first_balance == second_balance == 99990 and beads == 12
    results.append({"id": "economy-04", "balance_after_first": first_balance,
                    "balance_after_second": second_balance, "beads": beads, "charged": 10})

    p = player(810006, level=20)
    a = store.get_or_create_player(p["uin"])[0]
    b = store.get_or_create_player(p["uin"])[0]
    req = g.pb_varint_field(1, 4) + g.pb_varint_field(2, 20)
    call("Welfare_Take", req, a)
    call("Welfare_Take", req, b)
    assert store.get_item_count(p["uin"], 2002) == 10
    results.append({"id": "economy-07", "one_time_chest_claims": 2, "beans_received": 10,
                    "single_chest_expected": 5})

    p = player(810007, level=100)
    store.add_card(p["uin"], uid, 1101, 100)
    board = g.load_card_puzzle()[1]
    for index in range(board["width"] * board["height"]):
        store.add_card_filled_index(p["uin"], uid, index)
    g.main_quest_local.get_list(p["uin"], g._main_quest_rows())
    started = time.monotonic()
    try:
        call("Card_FinishFill", g.pb_int64_field(1, uid), p)
    except sqlite3.OperationalError as err:
        assert "locked" in str(err)
        assert store.get_card_fill_quality(p["uin"], uid) == 1
        assert len(store.get_card_filled_indices(p["uin"], uid)) == 9
        results.append({"id": "economy-01", "exception": str(err),
                        "elapsed_seconds": round(time.monotonic() - started, 3),
                        "quality_after_rollback": 1, "filled_cells": 9,
                        "quest_and_player_db_same": True})
    else:
        raise AssertionError("The confirmed FinishFill lock did not reproduce")
    store.close_thread_db()

(BASE / "evidence.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(results, ensure_ascii=True, indent=2))
print("CONFIRMED: 7 current bugs reproduced in disposable SQLite.")

